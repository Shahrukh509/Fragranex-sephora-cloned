<?php $__env->startSection('content'); ?>
<div class="container">
  <form id="edit-type-form" action="<?php echo e(route('admin.update.type')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($type->id??''); ?>">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <u class="text-color"><h4 class="text-color">Edit Type</h4></u>

    <div class="form-control">
    <label for="fname">Meta Title</label>
    <input type="text" id="mt" name="meta_title" value="<?php echo e($type->meta_title??''); ?>">
  </div>
 
  <div class="form-control">
    <label for="fname">Meta Description</label>
    <input type="text" id="md" name="meta_description" value="<?php echo e($type->meta_description??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">Meta Keyword</label>
    <input type="text" id="fname" name="meta_keyword" value="<?php echo e($type->meta_keyword??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">type Name</label>
    <input type="text" id="name" name="name" value="<?php echo e($type->name??''); ?>">
    <span class="text-danger error-text name_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select Parent</label>
    <select id="status" name="parent_id">
      <option disabled>Select Parent</option>
      <option value="">No Parent</option>
      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($typ->id); ?>" <?php if(isset($type->parent->id)): ?><?php echo e(($type->parent->id == $typ->id)? 'selected':''); ?><?php endif; ?>><?php echo e($typ->name??''); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </select>
  </div>

  <div class="form-control">

    <?php if(isset($type->image)): ?>
    <span style="padding-right:3px; padding-top: 3px; display:inline-block;">

      <img class="manImg" src="<?php echo e($type->image); ?>" width="200" height="200"></img>
      
      </span><br>
    <?php endif; ?>
    <label for="fname">Upload type Image</label><br>
    <input class="image-file" type="file" id="image" name="image" accept="image/*"><br>

    <span class="text-danger error-text image_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select Status</label>
    <select id="status" name="status">
      <option disabled>Select Status</option>
      <option value="1" <?php echo e(($type->status)? 'selected':''); ?>>Active</option>
      <option value="0" <?php echo e((!$type->status)? 'selected':''); ?>>InActive</option>
      
      
    </select>
  </div>
  
    <button class="text-white bg-gradient-primary" type="submit">Edit type</button>
  </form>
</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
                            // submitting form
$(document).on('submit','#edit-type-form',function(e){

  e.preventDefault();

  var url = $(this).attr('action');
  $.ajax({

    headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    type:"post",
    contentType: false,
    processData: false,
    url: url,
    data: new FormData(this),
    beforeSend:function(){
      Swal.fire({
              title: "Your type is being edited",
              text: "Please wait",
              imageUrl: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/eb7e7769321565.5ba1db95aab9f.gif",
              showConfirmButton: false,
              allowOutsideClick: false
            });

      $(document).find('span.error-text').text("");

    },
    success:function(response){

    if(response.status == true){
      const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 1000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'success',
      title: 'type has been updated!'
      }).then(function(){


        setTimeout(() => {

          location.href="<?php echo e(route('admin.show.type.list')); ?>";
          
        }, 1000);
      })


   


    }
    if(response.status == false){

       $.each(response.error,function(prefix,val){

        $('span.'+prefix+'_error').text('*'+val);
          

       });
       swal.close();

    }
  


      



    }

  });

});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/admin/type/edit_type.blade.php ENDPATH**/ ?>