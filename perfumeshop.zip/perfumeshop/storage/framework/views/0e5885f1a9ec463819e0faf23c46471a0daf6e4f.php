

<div class="product-single">
    <div class="row">
        <div class="col-lg-5 col-md-6 col-sm-12 col-12">
            <div class="product-details-img">
                <div class="product-thumb">
                    <div id="gallery" class="product-dec-slider-2 product-tab-left slick-initialized slick-slider slick-vertical">
                        <button class="slick-prev slick-arrow" aria-label="Previous" type="button" style="">Previous</button>
                        <div class="slick-list draggable" style="height: 280px;"><div class="slick-track" style="opacity: 1; height: 1512px; transform: translate3d(0px, -459px, 0px);">
                            <div class="slick-slide slick-cloned" data-slick-index="-5" id="" aria-hidden="true" style="width: 51px;" tabindex="-1">
                                <div>
                                    <a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="2" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a>
                       </div>
                    </div>
                    
                <div class="slick-slide slick-cloned" data-slick-index="-3" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        
                        <div class="slick-slide slick-cloned" data-slick-index="-2" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="5" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a></div></div>
                        <div class="slick-slide slick-cloned" data-slick-index="-1" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="6" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="0" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="-4" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="1" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="-3" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a></div></div><div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="3" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a>
                    </div>
                </div>
                <?php
                $parent = \App\Models\Product::where('id',$product->product_id)->first();
        
                ?>
                <?php $__currentLoopData = $parent->all_variable_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="slick-slide slick-current slick-active" data-slick-index="4" aria-hidden="false" style="width: 51px;"><div><a data-image="<?php echo e($get_image->image->path??''); ?>" data-zoom-image="<?php echo e($get_image->image->path??''); ?>" class="slick-slide slick-cloned" data-slick-index="0" aria-hidden="true" tabindex="0" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="<?php echo e($get_image->image->path??''); ?>" alt="">
                        </a>
                    </div>
                    
                    </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <button class="slick-next slick-arrow" aria-label="Next" type="button" style="">Next</button></div>
                </div>
                <div class="zoompro-wrap product-zoom-right pl-20">
                    <div class="zoompro-span">
                        <img class="blur-up zoompro lazyloaded" data-zoom-image="<?php echo e($product->image->path??""); ?>" alt="" src="<?php echo e($product->image->path??""); ?>">
                    </div>
                    <!-- <div class="product-labels"><span class="lbl on-sale">Sale</span><span class="lbl pr-label1">new</span></div>
                    <div class="product-buttons">
                        <a href="https://www.youtube.com/watch?v=93A2jOW5Mog" class="btn popup-video" title="View Video"><i class="icon anm anm-play-r" aria-hidden="true"></i></a>
                        <a href="#" class="btn prlightbox" title="Zoom"><i class="icon anm anm-expand-l-arrows"
                                aria-hidden="true"></i></a>
                    </div> -->
                </div>
                <!-- <div class="lightboximages">
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>

                </div> -->

            </div>
        </div>
        <div class="col-lg-7 col-md-6 col-sm-12 col-12">
            <div class="product-single__meta">
                <h1 class="product-single__title"><?php echo e($product->product->brand->name??''); ?></h1>
                <h6><?php echo e($product->product->name??''); ?> <?php echo e($product->product->type->name??''); ?></h6>
                <div class="product-nav clearfix">
                    <a href="#" class="next" title="Next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                </div>
                <div class="prInfoRow">
                    <div class="product-stock"><?php if($product->product->variable_products->in_stock): ?><span class="instock ">In Stock</span><?php else: ?><span class="outstock hide">Unavailable</span><?php endif; ?></div>
                    <div class="product-sku">Item: <span class="variant-sku">#<?php echo e($product->product->variable_products->id??''); ?></span></div>
                    <div class="product-review"><a class="reviewLink" href="#tab2"><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star-o"></i><i class="font-13 fa fa-star-o"></i><span class="spr-badge-caption">6
                                reviews</span></a></div>
                </div>
                <p class="product-single__price product-single__price-product-template">
                    <!-- <span class="visually-hidden">Regular price</span>
                    <s id="ComparePrice-product-template"><span class="money">$600.00</span></s> -->
                    <span class="product-price__price product-price__price-product-template product-price__sale product-price__sale--single">
                        <span id="ProductPrice-product-template"><span class="money">Rs <?php echo e(number_format($product->price)??''); ?></span></span>
                    </span>
                    
                </p>
                
                <p>Size: <?php echo e($product->size??''); ?> <?php echo e($product->type->name??''); ?></p>
            </div>



            <div class="standard_size pb-4">
                <div class="container">
                    <h6>Sizes</h6>
                    <div class="row">

                        <?php $__currentLoopData = $product->product->all_variable_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                            <div style="cursor: pointer;" class="perfume_box p-0 select-size <?php echo e(($pro->id==$product->id)?'border-danger':''); ?>" id="<?php echo e($pro->id??''); ?>">
                                <div class="row">
                                    
                                    <div class="col-4">

                                        <img src="img/s2249688+sw-42.webp" alt="" class="img-fluid ">
                                    </div>
                                     
                                    <div class="col-8 d-flex">
                                        <span class=" ml_size"><?php echo e($pro->size??''); ?> <?php echo e($pro->type->name??''); ?>

                                        
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        

                        


                    </div>

                    <br>
                    
                    
                </div>


            </div>

            <!-- Product Action -->
            <div class="product-action clearfix  product-template__container">
                <div class="product-form__item--quantity ">
                    <div class="wrapQtyBtn">
                        <div class="qtyField">
                            <a class="qtyBtn minus" href="javascript:void(0);">
                                <i class="" aria-hidden="true"></i>-</a>
                            <input type="text" id="Quantity" name="quantity" value="1" class="product-form__input qty">
                            <a class="qtyBtn plus" href="javascript:void(0);">
                                <i class="" aria-hidden="true">+</i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="product-form__item--submit">
                    <button type="button" name="add" class="btn product-form__cart-submit add-to-cart" id=<?php echo e($product->id??''); ?>>
                            <span>Add to cart</span>
                        </button>
                </div>
                
            </div>
            <!-- End Product Action -->

            <p id="freeShipMsg" class="freeShipMsg" data-price="199"><i class="fa fa-truck" aria-hidden="true"></i> GETTING CLOSER! ONLY <b class="freeShip"><span class="money" data-currency-usd="$199.00" data-currency="USD">$199.00</span></b> AWAY FROM <b>FREE SHIPPING!</b></p>
            <p class="shippingMsg"><i class="fa fa-clock-o" aria-hidden="true"></i> ESTIMATED DELIVERY BETWEEN <b id="fromDate">Wed. May 1</b> and <b id="toDate">Tue. May 7</b>.</p>
            <!-- <div class="userViewMsg" data-user="20" data-time="11000"><i class="fa fa-users" aria-hidden="true"></i>
                <strong class="uersView">14</strong> PEOPLE ARE LOOKING FOR THIS PRODUCT</div> -->
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/frontend/ajax/product_detail.blade.php ENDPATH**/ ?>