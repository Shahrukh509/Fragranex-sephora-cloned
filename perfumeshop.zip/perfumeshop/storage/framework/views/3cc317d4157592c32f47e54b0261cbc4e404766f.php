<?php $__env->startSection('title'); ?>
<?php echo e($category->title ?? 'No Title'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_title'); ?>
<?php echo e($category->meta_title ?? 'No MetaTitle'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_description'); ?>
<?php echo e($category->meta_description ?? 'No MetaDescription'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($category->meta_keyword ?? 'No MetaKeyword'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- main sec -->



<div role="main" id="content">
<section>
<div class="cart-wrapper std-side-padding put-remove-content-here">
<section id="CartTableAsyncSection">
<div class="cart-tip-wrapper-mobile">
</div>
<div class="c5-8-of-12 ">
<div class="name-line mq0none">
<input id="ItemCount" type="hidden" value="3">

<div class="serif">
Total (<span class="total-items">
<?php echo e(\Cart::getTotalQuantity()); ?>

</span>) items

<span class="mq2show">
: <bdo dir="ltr">RS <span class="all_total"><?php echo e(number_format(\Cart::getTotal())); ?>

</span>
</bdo>
</span>
<span class="mq2none">
<bdo dir="ltr">RS <span
class="all_total"><?php echo e(number_format(\Cart::getTotal())); ?></span></bdo>
</span>
</div>
</div>
<div id="cart-continueshopping-toplink">
<a class="cta" href="<?php echo e(route('front.home')); ?>">
Continue shopping
<svg class="cta-icon" width="12" height="12">
<use xlink:href="/Images/general-icon.svg?v=3#arrow-cta"></use>
</svg>
</a>
</div>
<div class="top-message" style="display:none">
</div>
<form method="get" action="/orders/checkoutvert" class="cart-button-top">
<div class="checkout-button mq4none">
<a class="btn-type-2" href="<?php echo e(route('front.show.checkout')); ?>"
aria-label="Proceed to Checkout">
<span class="mq4none">
Proceed to <span class="mq0show">Secure</span> Checkout
<img class="secure mq0show" alt="Padlock"
src="https://img.fragrancex.com/images//assets/icons/secure-padlock-icon.svg">
</span>
</a>
<noscript>
<input value="true" type="hidden" name="noscript" />
</noscript>
</div>
</form>
<div class="c4-12-of-12">
<div class="cart-grid">
<div class="cart-col-header ">
<div class="c3-3-of-12 c5-2-of-12 grey-header ">
Product Information
</div>
<div class="c3-9-of-12 c5-10-of-12 ">
<div class="c5-4-of-12 info-div "></div>
<div class="c5-8-of-12 price-div ">
<div class="c5-5-of-12 price-wrapper-header ">
    <div class="grey-header price-header">Price</div>
</div>
<div class="c5-3-of-12 qty-container-header ">
    <div class="grey-header">Quantity</div>
</div>
<div class="c5-4-of-12 total-wrapper-header ">
    <div class="grey-header">Total</div>
</div>
</div>
</div>
</div>
<div class="cartitems-padding">
<?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
// dd($value->attributes);
$product = \App\Models\ProductVariation::where('id', $value->id)->first();
$brand_slug = $product->product->brand->slug;

?>
<div class="cart-item-wrapper nonmessage cart-product ">
<div class="c0-5-of-12 c-4-of-12 c3-3-of-12 c5-2-of-12 item-img">
    <a href="<?php echo e(route('front.product.show', [$brand_slug, $product->product->slug])); ?>"
        aria-label="">
        <picture>
            <source
                srcset="<?php echo e($product->image->path??''); ?>"
                type="image/webp">
            <img src="<?php echo e($product->image->path??''); ?>"
                height="218" width="218">
        </picture>
    </a>
</div>
<div class="c0-7-of-12 c-8-of-12 c3-9-of-12 c5-10-of-12 item-content">
    <div class="c2-6-of-12 c5-4-of-12 info-div ">
        <h2 class="cart-item-name serif ">
            <a class="link-2"
                href="<?php echo e(route('front.product.show', [$brand_slug, $product->product->slug])); ?>"><?php echo e($value['name']); ?></a>
        </h2>
        <div class="cart-item-brand">by
            <?php echo e($product->product->brand->name ?? ''); ?></div>
        <div class="cart-item-sku mtn">Item #<?php echo e($product->id ?? ''); ?></div>
        <div class="cart-item-size">
            <?php echo e($value->attributes->size ?? ''); ?>

            <?php echo e($product->type->name ?? ''); ?>

        </div>
        <div class="stock-msg">
            <?php echo e($value->attributes->instock ? 'InStock' : 'OutOfStock'); ?>

        </div>
        <a href="<?php echo e(route('front.remove.from.cart',[$value->id])); ?>" id="<?php echo e($value->id); ?>">
            Remove
        </a>

    </div>
    <div class="c2-6-of-12 c5-8-of-12 price-div">
        <div
            class="c2-12-of-12 c5-7-of-12 column-wrapper mq2none price-wrapper">
            <div class="price-section">
                <div class="before-price"><bdo
                        dir="ltr">RS&nbsp;<?php echo e($value['price']); ?>

                    </bdo>
                    Regular Price</div>
                
            </div>
        </div>
        <div
            class="c2-12-of-12 c5-5-of-12 column-wrapper mq2show price-wrapper ">
            <div class="price-section">
                <div class="grey-label">Price</div>
                <div class="before-price">
                    <bdo dir="ltr">RS
                        <span
                            class=""><?php echo e(number_format($value->price)); ?>

                        </span></bdo>
                    Regular Price
                </div>
                
            </div>
        </div>
        <div class="c2-12-of-12 c5-3-of-12 column-wrapper qty-container ">
            <div class="grey-label">Quantity
                <span class="mq4none">:&nbsp;</span>
            </div>

            <div class="cart-qty-normal-dd">
                <div class="select-container">
                    <select class="cart-qty-select"
                        product-id="<?php echo e($value->id); ?>">
                        <?php
                            $qty = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10+'];
                            
                        ?>
                        <?php $__currentLoopData = $qty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($quantity); ?>"<?php echo e($value['quantity'] == $quantity ? 'selected' : ''); ?>>
                                <?php echo e($quantity); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                
            </div>
        </div>
        <div class="c5-4-of-12 column-wrapper mq4show total-wrapper ">
            <div class="price-section">
                <div class="before-price"><bdo dir="ltr">RS
                        <span
                            class="partial_total_<?php echo e($value['id']); ?>"><?php echo e(number_format($value->price * $value->quantity)); ?>

                        </span>
                    </bdo>
                </div>
                
            </div>
        </div>
    </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
</div>
</div>
</div>
<div class=" c5-4-of-12 summary-section">
<div class="order-summary-wrapper bg-padding">
<div class="checkout-btn-container mq4show-block">
<div class="checkout-button">
<a class="btn-type-2" href="<?php echo e(route('front.show.checkout')); ?>"
aria-label="Proceed to Checkout" aria-label="Proceed to Checkout">
Proceed to <span class="mq0show">Secure</span> Checkout
<img class="secure mq0show" alt="Padlock"
src="https://img.fragrancex.com/images//assets/icons/secure-padlock-icon.svg">
</a>
</div>

<div class="google-pay-wrapper"></div>
<div class="apple-pay-wrapper">
<a href="#" class="apple-pay-button-with-text" aria-label="Pay with apple pay">
<span class="text">Buy With</span>
<span class="logo"></span>
</a>
</div>
</div>
<div class="cart-tip-wrapper">
</div>
<div class="subtotal-section">
<div class="c-6-of-12">Subtotal</div>
<div class="c-6-of-12">
<bdo dir="ltr">RS <span
class="all_total"><?php echo e(number_format(Cart::getSubTotal())); ?></span></bdo>
</div>
</div>
<div class="line"></div>
<div class="total-section">
<div class="c-6-of-12">
Total </div>
<div class="c-6-of-12">
<bdo dir="ltr">RS <span
class="all_total"><?php echo e(number_format(Cart::getTotal())); ?></span></bdo>
</div>
</div>
<div class="checkout-btn-container mq4none-block">
<div class="checkout-button">
<a class="btn-type-2" href="<?php echo e(route('front.show.checkout')); ?>"
aria-label="Proceed to Checkout" aria-label="Proceed to Checkout">
Proceed to <span class="mq0show">Secure</span> Checkout
<img class="secure mq0show" alt="Padlock"
src="https://img.fragrancex.com/images//assets/icons/secure-padlock-icon.svg">
</a>
</div>
<div class="pp-summary-mobile">
<a class="paypal-checkout" href="/orders/cart/paypal.html">
Check out with
<img src="https://img.fragrancex.com/images/paypal.svg" alt="Pay by Paypal"
width="62" height="17">
</a>
</div>
<div class="google-pay-wrapper"></div>
<div class="apple-pay-wrapper">
<a href="#" class="apple-pay-button-with-text" aria-label="Pay with apple pay">
<span class="text">Buy With</span>
<span class="logo"></span>
</a>
</div>
</div>
</div>
<script>
var paymodel = {
"Wholesale": false,
"LoggedIn": false,
"IsEmpty": false,
"IsFlippedCurrency": false,
"Subtotal": 16524.96,
"ShowCouponDiscount": false,
"CouponDiscount": 0,
"ShowLoyaltyDiscount": false,
"LoyaltyDiscount": 0,
"ShowStoreCredit": false,
"StoreCredit": 0,
"GrandTotal": 16524.96,
"CurrencySymbol": "ARS $ ",
"CurrencyAbbreviation": "ARS",
"ContinueShoppingUrl": "https://www.a.com/products/_cid_perfume-am-lid_l-am-pid_884w__products.html",
"ShowTopMessage": false,
"TopMessage": null,
"CouponCode": "",
"ShowCouponMessage": false,
"CouponMessage": "Coupon  Applied",
"ShowGiftcertMessage": false,
"GiftcertMessage": "Gift Certificate  Applied",
"CouponGiftcertError": false,
"StoreCreditMessage": "COD Credit  Applied",
"ShowStoreCreditMessage": false,
"CouponGiftcertErrorMessage": " ",
"CartDetail": [{
"CartDetaiId": "6d2c57c4-4a32-43b2-94b3-15b527e2ee02",
"ProductCode": "69036",
"ImageUrl": "https://img.fragrancex.com/images/products/sku/small/69036.jpg",
"PageUrl": "/products/_cid_perfume-am-lid_l-am-pid_884w__products.html?sid=69036",
"Name": "Light Blue by Dolce \u0026 Gabbana 24 ml Eau De Toilette Spray for Women",
"LocName": "Light Blue by Dolce \u0026 Gabbana 24 ml Eau De Toilette Spray for women",
"ItemNumber": "418223",
"UnitPrice": 5508.32,
"UnitPriceBeforeSpecialVat": 5508.32,
"DiscountUnitPrice": 4682.07,
"DiscountUnitPriceUsdBeforeVat": 33.84,
"Price": 16524.96,
"PriceUsd": 119.43,
"PriceUsdBeforeSpecialVat": 119.4300,
"DiscountPrice": 14046.22,
"Quantity": 3,
"QuantityUpdated": false,
"InstockMsg": "In Stock.",
"WarningMsg": null,
"Brand": "Dolce+%26+Gabbana",
"BrandText": "by Dolce \u0026 Gabbana",
"NameShort": null,
"NameText": "Light Blue Perfume",
"SizeText": "0.8 oz",
"TypeText": "Eau De Toilette Spray",
"PinterestLikeItButtonItemViewModel": null,
"IsSubscription": false,
"ParentCode": null,
"Category": null,
"GaItemModel": {
"NameShort": "Light Blue",
"UnitPrice": 39.8100,
"Brand": "Dolce \u0026 Gabbana",
"Category": "Perfume",
"Type": "Eau De Toilette Spray",
"Size": "0.8 oz",
"AutoSku": "418223",
"Currency": "USD",
"Qty": 3,
"ParentCode": "884W"
}
}],
"ShowFreeShipMessage": false,
"ShowFreeShipLessThan59Message": false,
"LessThan59Message": null,
"PercentToFreeShipping": 0,
"ShowPercentFreeShipping": false,
"ShowCouponFreeShipMessage": false,
"ShowDiscountPrice": true,
"DiscountIsCoupon": true,
"IsEligible2DayShipping": false,
"ShowSpecialVatPriceMessage": false,
"SpecialVatPriceMessage": null,
"PageSuggestCouponApplied": false,
"CartGridViewModel": {
"IsEligible2DayShipping": false,
"ShowFreeShipLessThan59Message": false,
"CouponDiscount": 0,
"LoyaltyDiscount": 0,
"IsFlippedCurrency": false,
"ShowDiscountPrice": true,
"ContinueShoppingUrl": null,
"CurrencySymbol": "ARS $ ",
"CartDetail": [{
"CartDetaiId": "6d2c57c4-4a32-43b2-94b3-15b527e2ee02",
"ProductCode": "69036",
"ImageUrl": "https://img.fragrancex.com/images/products/sku/small/69036.jpg",
"PageUrl": "/products/_cid_perfume-am-lid_l-am-pid_884w__products.html?sid=69036",
"Name": "Light Blue by Dolce \u0026 Gabbana 24 ml Eau De Toilette Spray for Women",
"LocName": "Light Blue by Dolce \u0026 Gabbana 24 ml Eau De Toilette Spray for women",
"ItemNumber": "418223",
"UnitPrice": 5508.32,
"UnitPriceBeforeSpecialVat": 5508.32,
"DiscountUnitPrice": 4682.07,
"DiscountUnitPriceUsdBeforeVat": 33.84,
"Price": 16524.96,
"PriceUsd": 119.43,
"PriceUsdBeforeSpecialVat": 119.4300,
"DiscountPrice": 14046.22,
"Quantity": 3,
"QuantityUpdated": false,
"InstockMsg": "In Stock.",
"WarningMsg": null,
"Brand": "Dolce+%26+Gabbana",
"BrandText": "by Dolce \u0026 Gabbana",
"NameShort": null,
"NameText": "Light Blue Perfume",
"SizeText": "0.8 oz",
"TypeText": "Eau De Toilette Spray",
"PinterestLikeItButtonItemViewModel": null,
"IsSubscription": false,
"ParentCode": null,
"Category": null,
"GaItemModel": {
"NameShort": "Light Blue",
"UnitPrice": 39.8100,
"Brand": "Dolce \u0026 Gabbana",
"Category": "Perfume",
"Type": "Eau De Toilette Spray",
"Size": "0.8 oz",
"AutoSku": "418223",
"Currency": "USD",
"Qty": 3,
"ParentCode": "884W"
}
}],
"AllowQtyUpdate": true,
"AllowRemove": true,
"AllowNav": true,
"Wholesale": false,
"UseExpandedMq4Layout": false
},
"ShowCodCreditCodeWs": false
};
</script>

<div>
<form action="/widgets/recommendedcarousel/getcartrecommendedcarousel?itemToShow=6&amp;mode=1"
data-ajax="true" data-ajax-method="get" data-ajax-mode="replace"
data-ajax-success="initSlider('#AjaxRecommendedCarousel');initSliderAddToCart();"
data-ajax-update="#AjaxRecommendedCarousel" id="RecommendedAjaxForm" method="post">

</form>

</div>
</div>
<input id="UpdateText" name="UpdateText" type="hidden" value="Update">
<input id="RemoveText" name="RemoveText" type="hidden" value="REMOVE">
<input id="CurrencyAbbr" name="CurrencyAbbr" type="hidden" value="ARS">
</section>
<form action="/orders/cart" data-ajax="true" data-ajax-complete="initAfterCartAjaxLoad"
data-ajax-method="post" data-ajax-url="/widgets/carttable/ajaxcartable" id="ReloadCartAsyncForm"
method="post"><input id="continueUrl" name="continueUrl" type="hidden"
value="https://www.a.com/products/_cid_perfume-am-lid_l-am-pid_884w__products.html"></form>
<div>
<div class="xfactorshipping-wrapper">
<div class="c2-4-of-12">
<div><img class="lazy-img" src="https://img.fragrancex.com/images/search-loading.gif"
data-src="https://img.fragrancex.com/images/assets/icons/fastfreeshipping.svg"
width="60" height="60" alt=""></div>
<div>Delivery &amp; Returns</div>
<div>
<a href="#" class="cart-faq-link link-3">When will I get my order?
<div class="in">Choose speed on next page, most orders ship the same day.<div
class="line"></div>
</div>
</a>
<a href="#" class="cart-faq-link link-3">Any Taxes and Duties?
<div class="in">No tax in some states, some countries may collect duties, but most
do not.<div class="line"></div>
</div>
</a>
<a href="#" class="cart-faq-link link-3">Ship to PO Box/APO/FPO?
<div class="in">Sure, but delivery will take longer outside USA.<div
class="line"></div>
</div>
</a>
<a href="#" class="cart-faq-link link-3">Are products authentic?
<div class="in">All items are 100% original and authentic.<div class="line">
</div>
</div>
</a>
<a href="#" class="cart-faq-link link-3">How do I make a return?
<div class="in">Simply send it back to us, in USA email or call for a free return
label.<div class="line"></div>
</div>
</a>
</div>
</div>
<div class="c2-4-of-12">
<div><img class="lazy-img" src="https://img.fragrancex.com/images/search-loading.gif"
data-src="https://img.fragrancex.com/images/assets/icons/safesecure.svg"
width="60" height="60" alt=""></div>
<div>100% Safe and Secure</div>
<div>Your transactions are 100% safe and secure, encrypted with Secure Socket Layer (SSL) by
Verisign.
</div>
</div>
<div class="c2-4-of-12">
<div><img class="lazy-img" src="https://img.fragrancex.com/images/search-loading.gif"
data-src="https://img.fragrancex.com/images/assets/icons/customerservice.svg"
width="60" height="60" alt=""></div>
<div>Have a question?</div>
<div>
<div>Call us from 7AM - 4PM EST </div>
<div>Monday - Friday</div>
<div>In the USA</div>
<div><a href="tel:18885573738" auto-tracked="true">1-888-557-3738</a></div>
<div>Outside the USA </div>
<div><a href="tel:0017184826970" auto-tracked="true">001-718-482-6970</a></div>
</div>
</div>
</div>
</div>
<div class="shop-sliders bg-padding">
<div>
<form action="/widgets/previouslyviewed/ajaxpreviouslyviewed" data-ajax="true"
data-ajax-method="get" data-ajax-mode="replace"
data-ajax-success="initSlider('#AjaxPreviouslyViewed')"
data-ajax-update="#AjaxPreviouslyViewed" id="PreviousViewedAsyncForm" method="post"></form>
<section id="AjaxPreviouslyViewed">
<h3 class="title serif">Recently Viewed</h3>
<div class="slider">
<div class="slider-wrapper">
<div class="slider-content">
<div class="content-container">
<div class="content slide-0">
    <a href="/products/_cid_perfume-am-lid_l-am-pid_884w__products.html"
        class="click-box">
        <div>
            <picture class="lazy-img">
                <source
                    data-srcset="https://img.fragrancex.com/images/products/sku/small/884w.webp"
                    type="image/webp">
                <img src="https://img.fragrancex.com/images/search-loading.gif"
                    data-src="https://img.fragrancex.com/images/products/sku/small/884w.jpg"
                    width="206" height="206" alt="Light Blue">
            </picture>
        </div>
        <div class="desc-section">
            <div class="serif h3">
                Light Blue
            </div>
            <div>
                By Dolce &amp; Gabbana
            </div>
            <div class="product-review ">
                <div class="p-w-r">
                    <div class="pr-stars lazy-img">
                        <div class="stars-total lazy-img" style="width: 92%;">
                        </div>
                    </div>
                    <div class="review-count">
                        (<span>1735</span>)
                    </div>
                </div>
            </div>
            <div class="slider-price">
                <span>As low as</span> <bdo dir="ltr">ARS
                    $&nbsp;39.81</bdo>
            </div>
        </div>
    </a>
</div>
<input type="hidden" class="ga-item-model"
    value="{&quot;NameShort&quot;:&quot;Light Blue&quot;,&quot;UnitPrice&quot;:null,&quot;Brand&quot;:&quot;Dolce &amp; Gabbana&quot;,&quot;Category&quot;:&quot;Perfume&quot;,&quot;Type&quot;:null,&quot;Size&quot;:null,&quot;AutoSku&quot;:null,&quot;Currency&quot;:&quot;USD&quot;,&quot;Qty&quot;:1,&quot;ParentCode&quot;:&quot;884W&quot;}">
</div>
<div class="content-container">
<div class="content slide-1">
    <a href="/products/_cid_perfume-am-lid_p-am-pid_60332w__products.html"
        class="click-box">
        <div>
            <picture class="lazy-img">
                <source
                    data-srcset="https://img.fragrancex.com/images/products/sku/small/60332w.webp"
                    type="image/webp">
                <img src="https://img.fragrancex.com/images/search-loading.gif"
                    data-src="https://img.fragrancex.com/images/products/sku/small/60332w.jpg"
                    width="206" height="206" alt="Pink Sugar">
            </picture>
        </div>
        <div class="desc-section">
            <div class="serif h3">
                Pink Sugar
            </div>
            <div>
                By Aquolina
            </div>
            <div class="product-review ">
                <div class="p-w-r">
                    <div class="pr-stars lazy-img">
                        <div class="stars-total lazy-img" style="width: 92%;">
                        </div>
                    </div>
                    <div class="review-count">
                        (<span>1053</span>)
                    </div>
                </div>
            </div>
            <div class="slider-price">
                <span>As low as</span> <bdo dir="ltr">ARS
                    $&nbsp;2.99</bdo>
            </div>
        </div>
    </a>
</div>
<input type="hidden" class="ga-item-model"
    value="{&quot;NameShort&quot;:&quot;Pink Sugar&quot;,&quot;UnitPrice&quot;:null,&quot;Brand&quot;:&quot;Aquolina&quot;,&quot;Category&quot;:&quot;Perfume&quot;,&quot;Type&quot;:null,&quot;Size&quot;:null,&quot;AutoSku&quot;:null,&quot;Currency&quot;:&quot;USD&quot;,&quot;Qty&quot;:1,&quot;ParentCode&quot;:&quot;60332W&quot;}">
</div>
<div class="content-container">
<div class="content slide-2">
    <a href="/products/_cid_perfume-am-lid_o-am-pid_1002w__products.html"
        class="click-box">
        <div>
            <picture class="lazy-img">
                <source
                    data-srcset="https://img.fragrancex.com/images/products/sku/small/1002w.webp"
                    type="image/webp">
                <img src="https://img.fragrancex.com/images/search-loading.gif"
                    data-src="https://img.fragrancex.com/images/products/sku/small/1002w.jpg"
                    width="206" height="206" alt="Obsession">
            </picture>
        </div>
        <div class="desc-section">
            <div class="serif h3">
                Obsession
            </div>
            <div>
                By Calvin Klein
            </div>
            <div class="product-review ">
                <div class="p-w-r">
                    <div class="pr-stars lazy-img">
                        <div class="stars-total lazy-img" style="width: 92%;">
                        </div>
                    </div>
                    <div class="review-count">
                        (<span>923</span>)
                    </div>
                </div>
            </div>
            <div class="slider-price">
                <span>As low as</span> <bdo dir="ltr">ARS
                    $&nbsp;24.68</bdo>
            </div>
        </div>
    </a>
</div>
<input type="hidden" class="ga-item-model"
    value="{&quot;NameShort&quot;:&quot;Obsession&quot;,&quot;UnitPrice&quot;:null,&quot;Brand&quot;:&quot;Calvin Klein&quot;,&quot;Category&quot;:&quot;Perfume&quot;,&quot;Type&quot;:null,&quot;Size&quot;:null,&quot;AutoSku&quot;:null,&quot;Currency&quot;:&quot;USD&quot;,&quot;Qty&quot;:1,&quot;ParentCode&quot;:&quot;1002W&quot;}">
</div>
</div>
</div>
<div class="slider-circles">
<div>
<span class="item-select slider-0   checked">

</span>
</div>
<div>
<span class="item-select slider-1 "></span>
</div>
</div>
<div class="slider-nav">
<div class="prev" disabled="disabled">
<button disabled="disabled" data-slide="-1" class="review-nav">
<img class="prev lazy-img"
    src="https://img.fragrancex.com/images/search-loading.gif"
    data-src="https://img.fragrancex.com/images/assets/ui/sliderleft.svg"
    alt="View Previous Items" width="50" height="50"
    disabled="disabled">
</button>
</div>
<div class="next" disabled="disabled">
<button data-slide="1" class="review-nav" disabled="disabled">
<img class="next lazy-img"
    src="https://img.fragrancex.com/images/search-loading.gif"
    data-src="https://img.fragrancex.com/images/assets/ui/sliderleft.svg"
    width="50" height="50" alt="View Next Items" disabled="disabled">
</button>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
</div>
<?php $__env->startPush('child-scripts'); ?>
<script type="text/javascript">
// updating cart

$(document).on('change', '.cart-qty-select', function() {

var qty = $(this).find('option:selected').val();
var product_id = $(this).attr('product-id');
var url = "<?php echo e(route('front.update.cart')); ?>";

$.ajax({

headers: {
'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
},

type: "patch",
data: {
id: product_id,
qty: qty
},
url: url,

success: function(response) {

if (response.success == true) {

$('.all_total').html(response.all_total);
$('.total-items').html(response.total_items);
$('.partial_total_'+response.id).html(response.partial_total);
$('.add-total-items').html(response.total_items);

// alert(response.all_total);


} else {

return false;
}




}

});

});
// Removing from cart

// $(document).on('click', '.remove-cart', function(e) {
// e.preventDeafult();

// alert('hihihihhi');
    
    
// var product_id = $(this).attr('id');
// var url = "<?php echo e(route('front.remove.from.cart')); ?>";



// // alert(product_id);
// // return false;

// $.ajax({

// type: "get",
// data: {
// id: product_id
// },
// url: url,

// success: function(response) {

// if (response.success == true && response.item == true) {

// const Toast = Swal.mixin({
// toast: true,
// position: 'top-end',
// showConfirmButton: false,
// timer: 3000,
// timerProgressBar: true,
// });

// Toast.fire({
// icon: 'success',
// title: 'Item has been deleted!'
// });

// location.href = "/cart";


// }
// if (response.success == true) {

// $('.put-remove-content-here').html(response.view);
// }




// }

// });

// });
</script>
<?php $__env->stopPush(); ?>

<!-- main sec  ends-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/frontend/cart.blade.php ENDPATH**/ ?>