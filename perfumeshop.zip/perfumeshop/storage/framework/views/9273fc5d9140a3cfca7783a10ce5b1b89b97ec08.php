<?php $__env->startSection('content'); ?>
<div class="container">
  <form id="add-category-form" action="<?php echo e(route('admin.add.category')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" >
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <u class="text-color"><h4 class="text-color">Add Category</h4></u>

    <div class="form-control">
    <label for="fname">Meta Title</label>
    <input type="text" id="mt" name="meta_title" >
  </div>
 
  <div class="form-control">
    <label for="fname">Meta Description</label>
    <input type="text" id="md" name="meta_description">
  </div>
  <div class="form-control">
    <label for="fname">Meta Keyword</label>
    <input type="text" id="fname" name="meta_keyword">
  </div>
  <div class="form-control">
    <label for="fname">Category Name</label>
    <input type="text" id="name" name="name">
    <span class="text-danger error-text name_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select parent of this category</label>
    <select id="status" name="parent_id">
      <option disabled>Select Status</option>
      <option value="">Null</option>
      <?php $__currentLoopData = $parent_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </select>
  </div>

  <div class="form-control">

    <label for="fname">Upload Category Image</label><br>
    <input class="image-file" type="file" id="image" name="image" accept="image/*"><br>

    <span class="text-danger error-text image_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select Status</label>
    <select id="status" name="status">
      <option disabled>Select Status</option>
      <option value="1" >Active</option>
      <option value="0" >InActive</option>
      
      
    </select>
  </div>
  
    <button class="text-white bg-gradient-primary" type="submit">Edit category</button>
  </form>
</div> 
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
                            // submitting form
$(document).on('submit','#add-category-form',function(e){

  e.preventDefault();

  // form = $('#add-category-form').serialize();
  var url = $(this).attr('action');
  $.ajax({

    headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    type:"post",
    contentType: false,
    processData: false,
    url: url,
    data: new FormData(this),
    beforeSend:function(){
      Swal.fire({
              title: "Your category is being uploaded",
              text: "Please wait",
              imageUrl: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/eb7e7769321565.5ba1db95aab9f.gif",
              showConfirmButton: false,
              allowOutsideClick: false
            });

      $(document).find('span.error-text').text("");

    },
    success:function(response){

    if(response.status == true){
      const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 10000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'success',
      title: 'category has been uploaded!'
      }).then(function(){

        setTimeout(() => {

          location.href="<?php echo e(route('admin.show.category.list')); ?>";

        
        }, 1000);
        

        });


      


    }
    if(response.status == false){

       $.each(response.error,function(prefix,val){

        $('span.'+prefix+'_error').text('*'+val);
          

       });
       swal.close();

    }
  


      



    }

  });

});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/admin/category/add_category.blade.php ENDPATH**/ ?>