<?php $__env->startSection('content'); ?>
<div class="container">
  <form id="edit-category-form" action="<?php echo e(route('admin.update.category')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($category->id??''); ?>">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <u class="text-color"><h4 class="text-color">Edit Category</h4></u>

    <div class="form-control">
    <label for="fname">Meta Title</label>
    <input type="text" id="mt" name="meta_title" value="<?php echo e($category->meta_title??''); ?>">
  </div>
 
  <div class="form-control">
    <label for="fname">Meta Description</label>
    <input type="text" id="md" name="meta_description" value="<?php echo e($category->meta_description??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">Meta Keyword</label>
    <input type="text" id="fname" name="meta_keyword" value="<?php echo e($category->meta_keyword??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">Category Name</label>
    <input type="text" id="name" name="name" value="<?php echo e($category->name??''); ?>">
    <span class="text-danger error-text name_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select parent of this category</label>
    <select id="status" name="parent_id">
      <option disabled>Select Status</option>
      <option value="">Null</option>
      <?php $__currentLoopData = $parent_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($parent->id??''); ?>" <?php echo e(($category->parent->id??null==$parent->id)? 'selected':''); ?>><?php echo e($parent->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </select>
  </div>

  <div class="form-control">

    <?php if(isset($category->image)): ?>
    <span style="padding-right:3px; padding-top: 3px; display:inline-block;">

      <img class="manImg" src="<?php echo e($category->image); ?>" width="200" height="200"></img>
      
      </span><br>
    <?php endif; ?>
    <label for="fname">Upload Category Image</label><br>
    <input class="image-file" type="file" id="image" name="image" accept="image/*"><br>

    <span class="text-danger error-text image_error"></span>
  </div>

  <div class="form-control">
    <label for="featured">Select Status</label>
    <select id="status" name="status">
      <option disabled>Select Status</option>
      <option value="1" <?php echo e(($category->status)? 'selected':''); ?>>Active</option>
      <option value="0" <?php echo e((!$category->status)? 'selected':''); ?>>InActive</option>
      
      
    </select>
  </div>
  
    <button class="text-white bg-gradient-primary" type="submit">Edit category</button>
  </form>
</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
                            // submitting form
$(document).on('submit','#edit-category-form',function(e){

  e.preventDefault();

  var url = $(this).attr('action');
  $.ajax({

    headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    type:"post",
    contentType: false,
    processData: false,
    url: url,
    data: new FormData(this),
    beforeSend:function(){
      Swal.fire({
              title: "Your category is being edited",
              text: "Please wait",
              imageUrl: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/eb7e7769321565.5ba1db95aab9f.gif",
              showConfirmButton: false,
              allowOutsideClick: false
            });

      $(document).find('span.error-text').text("");

    },
    success:function(response){

    if(response.status == true){
      const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 12000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'success',
      title: 'category has been updated!'
      });


      location.href="<?php echo e(route('admin.show.category.list')); ?>";


    }
    if(response.status == false){

       $.each(response.error,function(prefix,val){

        $('span.'+prefix+'_error').text('*'+val);
          

       });
       swal.close();

    }
  


      



    }

  });

});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/admin/category/edit_category.blade.php ENDPATH**/ ?>