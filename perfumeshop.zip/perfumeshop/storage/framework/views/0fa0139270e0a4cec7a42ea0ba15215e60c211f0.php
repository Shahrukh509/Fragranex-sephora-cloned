 <!-- Developed by shahrukh siddiqui -->
<!DOCTYPE html>
<html class="no-js" lang="en" style="overflow-y: scroll;">

<head>
    <meta name="google" content="notranslate">
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="title" content="<?php echo $__env->yieldContent('meta_title'); ?>">
     <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
     <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
     <link rel="canonical" href="<?php echo e(url()->current()); ?>"/>
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
   
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5, minimum-scale=1" />
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/style.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/products.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/nc_exts.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/nc_ext_v.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/plugins.css')); ?>">
    

    <link rel="preload" href="<?php echo e(asset('public/frontend/css/c_style.css')); ?>" as="style">



   
    <!-- bootstrap 4 cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

    
    <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous">
  </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js">
        
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body id="top">

    <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('content'); ?>
    
  
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<script>

    $(document).ready(function() {

        $(".owl-carousel").owlCarousel({

            autoPlay: 3000,
            items: 4,
            itemsDesktop: [1199, 3],
            itemsDesktopSmall: [979, 3],
            center: true,
            nav: true,
            loop: true,
            responsive: {
                600: {
                    items: 3
                }
            }
        });



        $(".owl-carousel_1").owlCarousel({

            autoPlay: 3000,
            items: 4,
            itemsDesktop: [1199, 3],
            itemsDesktopSmall: [979, 3],
            center: true,
            nav: true,
            loop: true,
            responsive: {
                600: {
                    items: 3
                }
            }
        });

    });


    // new cara 
    $(document).ready(function() {


        if ($('.bbb_viewed_slider').length) {
            var viewedSlider = $('.bbb_viewed_slider');

            viewedSlider.owlCarousel({
                loop: true,
                margin: 30,
                autoplay: true,
                autoplayTimeout: 6000,
                nav: false,
                dots: false,
                responsive: {
                    0: {
                        items: 1
                    },
                    575: {
                        items: 2
                    },
                    768: {
                        items: 3
                    },
                    991: {
                        items: 4
                    },
                    1199: {
                        items: 6
                    }
                }
            });

            if ($('.bbb_viewed_prev').length) {
                var prev = $('.bbb_viewed_prev');
                prev.on('click', function() {
                    viewedSlider.trigger('prev.owl.carousel');
                });
            }

            if ($('.bbb_viewed_next').length) {
                var next = $('.bbb_viewed_next');
                next.on('click', function() {
                    viewedSlider.trigger('next.owl.carousel');
                });
            }
        }


    });
    </script> 
   
    
    <script src="<?php echo e(asset('public/frontend/js/email-decode.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('public/frontend/js/manifest.js')); ?>"></script>
   
   
    
  
    
                     

        

<?php echo $__env->yieldPushContent('child-scripts'); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>