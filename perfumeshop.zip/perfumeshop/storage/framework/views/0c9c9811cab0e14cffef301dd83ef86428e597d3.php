<?php $__env->startSection('content'); ?>
<div class="container">
  <form id="edit-product-form" action="<?php echo e(route('admin.update.product')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <u class="text-color"><h4 class="text-color">Edit Product</h4></u>

    <div class="form-control">
    <label for="fname">Meta Title</label>
    <input type="text" id="mt" name="meta_title" placeholder="Meta title for SEO" value="<?php echo e($product->meta_title??''); ?>">
  </div>
 
  <div class="form-control">
    <label for="fname">Meta Description</label>
    <input type="text" id="md" name="meta_description" value="<?php echo e($product->meta_description??''); ?>" >
  </div>
  <div class="form-control">
    <label for="fname">Meta Keyword</label>
    <input type="text" id="fname" name="meta_keyword" value="<?php echo e($product->meta_keyword??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">Product Name</label>
    <input type="text" id="name" name="name" value="<?php echo e($product->name??''); ?>">
    <span class="text-danger error-text name_error"></span>
  </div>
  <div class="form-control">
    <label for="fname">Upload Product Image</label><br>
    <?php if(isset($product->image)): ?>
     <?php $__currentLoopData = $product->images->where('product_variation_id',''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span class="images" style="padding-right:3px; padding-top: 3px; display:inline-block;">

      <img class="manImg" src="<?php echo e($prod_image->path); ?>" width="200" height="200"></img>
      
      </span><br>
    <div class="clone-image">
    <input class="image-file" type="file" id="image" name="image[]" accept="image/*" value="<?php echo e($prod_image->path??''); ?>">
  </div>
  <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <span class="text-danger error-text image_error"></span>
  </div>
  <div class="put-image-div">

  </div>
  <a class="add-more-image" href="#">+ Add more image</a>

  <div class="form-control">
    <label for="country">Select Category</label>
    <select id="category" name="category">
      <option disabled>Select Desired Category</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($category->id??''); ?>" <?php echo e(($category->id == $product->category_id)? 'selected':''); ?>><?php echo e($category->slug??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text category_error"></span>
  
  </div>

  <div class="form-control">
    <label for="country">Select Brand</label>
    <select id="brand" name="brand">
      <option disabled>Select Desired Brand</option>
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($brand->id??''); ?>" <?php echo e(($brand->id == $product->brand_id )? 'selected':''); ?>><?php echo e($brand->name??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text brand_error"></span>
  
  </div>

  <div class="form-control">
    <label for="country">Select Type</label>
    <select id="type" name="type">
      <option disabled >Select Desired Type</option>
      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($type->id??''); ?>" <?php echo e(($type->id == $product->type_id )? 'selected':''); ?>><?php echo e($type->name??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text type_error"></span>
  
  
  </div>

  <div class="form-control">
    <label for="country">Select Departnment</label>
    <select id="department" name="department">
      <option disabled >Select Desired Department</option>
      <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($dept->id??''); ?>" <?php echo e(($dept->id == $product->department_id )? 'selected':''); ?>><?php echo e($dept->name??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text department_error"></span>
  
  </div>

  <div class="form-control">
    <label for="">Select Scent&Notes</label>
    <select id="scent_notes" name="scent_notes">
      <option disabled >Select Desired Scent&Notes</option>
      <?php $__currentLoopData = $scents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($scent->id??''); ?>" <?php echo e(($scent->id == $product->scent_notes_id)? 'selected':''); ?>><?php echo e($scent->name??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text scent_notes_error"></span>
  
  </div>
  <div class="form-control">
    <label for="fname">Product Description</label><br>
    <textarea name="description" id="description" cols="30" rows="4"><?php echo e($product->description??''); ?></textarea>

  </div>

  <div class="form-control">
    <label for="fname">Product Minimum Price Rs</label>
    <input type="number" id="min_price" name="min_price" value="<?php echo e($product->min_price??''); ?>"><br>
    <span class="text-danger error-text min_price_error"></span>
  </div>
  <div class="form-control">
    <label for="fname">Product Maximum Price Rs</label>
    <input type="number" id="max_price" name="max_price" value="<?php echo e($product->max_price??''); ?>"><br>
    <span class="text-danger error-text max_price_error"></span>
  </div>
  <div class="form-control">
    <label for="featured">Select Featured</label>
    <select id="featured" name="featured ">
      <option disabled >Is it Featured Product?</option>
      <option value="1"<?php echo e(($product->featured)? 'selected':''); ?>>Yes</option>
      <option value="0"<?php echo e((!$product->featured)? 'selected':''); ?>>No</option>
      
      
    </select>
  </div>

  <div class="form-control">
    <label for="featured">Select Stock</label>
    <select id="in_stock" name="in_stock">
      <option disabled selected>Select Stock Status</option>
      <option value="1"<?php echo e(($product->in_stock)? 'selected':''); ?>>In Stock</option>
      <option value="0"<?php echo e((!$product->in_stock)? 'selected':''); ?>>Out Of Stock</option>
      
      
    </select>
  </div>
  <div class="form-control">
    <label for="featured">Select Status</label>
    <select id="status" name="status">
      <option disabled selected>Select Status</option>
      <option value="1"<?php echo e(($product->status)? 'selected':''); ?>>Active</option>
      <option value="0"<?php echo e((!$product->status)? 'selected':''); ?>>Inactive</option>
      
      
    </select>
  </div>
</div>


                                

 <?php $__currentLoopData = $product->all_variable_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$vary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg-8 col-sm-8 col-md-8 clone-to-be">

<input class="data-status" type="hidden" name="data_status" value="old">

<a id="delete-this"class="delete-variation" vary-id="<?php echo e($vary->id); ?>"  href="<?php echo e(route('admin.delete.product')); ?>"><i class="fa fa-window-close" aria-hidden="true"></i></a>
  
  <u class="text-color"><h4 class="text-color"><span class="vary_num"><?php echo e($key+1); ?>.</span>Edit Product Variation</h4></u>
  <div class="form-control">
    <label for="country">Select Type</label>
    <select  name="variation_type[]">
      <option disabled>Select Desired Type</option>
      <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($type->id??''); ?>" <?php echo e(($type->id == $vary->type_id)? 'selected':''); ?>><?php echo e($type->name??''); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </select>

    <span class="text-danger error-text variation_type_error"></span>
  
  
  </div>
  <div class="form-control">
    <label for="fname">Upload Product Variation Image</label><br>

    <span style="padding-right:3px; padding-top: 3px; display:inline-block;">

      <img class="manImg" src="<?php echo e($vary->image->path??''); ?>" width="200" height="200"></img>
      
      </span><br>

    <div class="clone-image-variation">
      
      <input class="image-file" type="file" id="image" name="variation_image[]" accept="image/*"><br>

    </div>
  
    <span class="text-danger error-text variation_image_error"></span>
  </div>
  <div class="put-image-variation-div">

  </div>
  

  <div class="form-control">
    <label for="fname">Variation Size</label>
    <input type="text"  name="variation_size[]" value="<?php echo e($vary->size??''); ?>">
    <span class="text-danger error-text variation_size_error"></span>
  </div>

  <div class="form-control">
    <label for="fname">Variation Color</label>
    <input type="text" name="variation_color[]" value="<?php echo e($vary->color??''); ?>">
  </div>


  <div class="form-control">
    <label for="fname">Variation Quantity</label>
    <input type="number" name="variation_quantity[]" value="<?php echo e($vary->quantity??''); ?>">
  </div>
  <div class="form-control">
    <label for="fname">Variation Price</label>
    <input type="number" name="variation_price[]" value="<?php echo e($vary->price??''); ?>"><br>
    <span class="text-danger error-text variation_price_error"></span>
  </div>
  <div class="form-control">
    <label for="fname">Variation Special Price</label>
    <input type="number"  name="variation_special_price[]" value="<?php echo e($vary->special_price??''); ?>">
  </div>


  <div class="form-control">
    <label for="featured">Select Stock</label>
    <select name="variation_stock[]">
      <option disabled selected>Select Stock Status</option>
      <option value="1"<?php echo e(($vary->in_stock)? 'selected':''); ?>>In Stock</option>
      <option value="0"<?php echo e((!$vary->in_stock)? 'selected':''); ?>>Out Of Stock</option>
      
      
    </select>
  </div>

  <div class="form-control">
    <label for="featured">Select Status</label>
    <select name="variation_status[]">
      <option disabled selected>Select Status</option>
      <option value="1"<?php echo e(($vary->status)? 'selected':''); ?>>Active</option>
      <option value="0"<?php echo e((!$vary->status)? 'selected':''); ?>>Inactive</option>
      
      
    </select>
  </div>

  <div class="form-control">
    <label for="fname">Any Note</label><br>
    <textarea name="variation_note[]" cols="30" rows="4"><?php echo e($vary->note??''); ?></textarea>
  </div>
 
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="add-here">
    
</div>

<a class="add-more" href="#">+ Add more variation</a>
<a id="delete-this" href="#">- Remove more variation</a>

    </div>

    <br>
  
    <button class="text-white bg-gradient-primary" type="submit">Edit product</button>
  </form>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
  $(document).on('click','.add-more',function(){
 
    var clone =  $(".clone-to-be").first().clone().appendTo('.add-here').find("input").val("").end();
    $('.vary_num').text('New ');

    clone.find("input[name='data_status']").val("new");
    // $(this).find('[name="variation_type[]"] option:selected').removeAttr('selected');

  });

  $(document).on('click','.add-more-image-variation',function(){
 
    $(".clone-image-variation").first().clone().appendTo('.put-image-variation-div').find("input").val("").end();

});
$(document).on('click','.add-more-image',function(){
 
 var clone = $(".clone-image").first().clone().appendTo('.put-image-div').find("input").val("").end();
//  clone.find('select[name="variation_type[]"]').removeAttr('selected').end().html();
});
$(document).on('click','#delete-this',function(){

$(".add-here").find(".clone-to-be:last").remove();

});

                            // submitting form
$(document).on('submit','#edit-product-form',function(e){

  e.preventDefault();

  var url = $(this).attr('action');
  // var product_id = ;
  $.ajax({

    headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    type:"post",
    contentType: false,
    processData: false,
    url: url,
    data: new FormData(this),
    beforeSend:function(){
      Swal.fire({
              title: "Your product is being edited",
              text: "Please wait",
              imageUrl: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/eb7e7769321565.5ba1db95aab9f.gif",
              showConfirmButton: false,
              allowOutsideClick: false
            });

      $(document).find('span.error-text').text("");

    },
    success:function(response){

    if(response.status == true){
      const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'success',
      title: 'Product has been updated!'
      }).then(function(){

        setTimeout(() => {

          location.href="<?php echo e(route('admin.show.product.list')); ?>";
          
        }, 1000);


    });
  }
    if(response.status == false){

       $.each(response.error,function(prefix,val){

        $('span.'+prefix+'_error').text('*'+val);
          

       });
       swal.close();

    }
  


      



    }

  });

});

$(document).on('click','.delete-variation',function(e){

e.preventDefault();
var x=confirm( "Are you sure you want to delete?!");
var url = $(this).attr('href');
var id = $(this).attr('vary-id');
if(x){

    $.ajax({

      url: url,
      data: {id:id },
      beforeSend:function(){
        Swal.fire({
                title: "Your variation product is being deleted",
                text: "Please wait",
                imageUrl: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/eb7e7769321565.5ba1db95aab9f.gif",
                showConfirmButton: false,
                allowOutsideClick: false
              });

        $(document).find('span.error-text').text("");

      },
      success:function(response){

      if(response.status == true){
        const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'success',
      title: 'Product has been deleted!'
      });

      location.reload();
  }
      if(response.status == false){

        
        const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      });

      Toast.fire({
      icon: 'error',
      title: 'Unable to delete variation!'
      });

    }


    }

  });

}
});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/admin/product/edit_product.blade.php ENDPATH**/ ?>