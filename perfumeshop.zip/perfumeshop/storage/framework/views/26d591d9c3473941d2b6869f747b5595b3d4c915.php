<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 mb-3" >
  <div class="row d-flex justify-content-center">
    <button class="btn btn-danger" id="print"> Print This</button>
      <div class="col-md-8">
          <div class="card" id="print_area">
              <div class="d-flex flex-row p-2"> <img src="https://img.freepik.com/free-vector/minimal-yellow-invoice-template-vector-design_1017-12070.jpg?w=2000" width="48">
                  <div class="d-flex flex-column"> <span class="font-weight-bold">Invoice</span> <small>INV-<?php echo e($order->id); ?></small> </div>
              </div>
              <hr>
              <div class="table-responsive p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                              <td>Order Tracking No#</td>
                              <td>Billing Address</td>
                              <td>Shipping Address</td>
                              <td>Payment Method</td>

                          </tr>
                          <tr class="content">
                              <td class="font-weight-bold"><?php echo e($order->tracking_number??''); ?></td>
                              <td class="font-weight-bold content-wrap"><?php echo e($order->address_1?? $order->address_2); ?></td>
                              <td class="font-weight-bold"><?php echo e($user->address_1?? $user->address_2); ?></td>
                              <td class="font-weight-bold"><?php echo e($order->payment_method??''); ?></td>
                            
                          </tr>
                      </tbody>
                  </table>
              </div>
              <hr>
              <div class="products p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                              <td>Product</td>
                              <td>Sku</td>
                              <td>Size</td>
                              <td>Qty</td>
                              <td>Price</td>
                              <td class="text-center">Total</td>
                          </tr>
                          <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="content">
                              <td><?php echo e($detail->variable_product->product->name??''); ?></td>
                              <td><?php echo e($detail->variable_product->sku??''); ?></td>
                              <td><?php echo e($detail->variable_product->size??''); ?></td>
                              <td><?php echo e($detail->quantity??''); ?></td>
                              <td class="text-center"><?php echo e($detail->price??''); ?></td>
                          </tr>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                      </tbody>
                  </table>
              </div>
              <hr>
              <div class="products p-2">
                  <table class="table table-borderless">
                      <tbody>
                          <tr class="add">
                            
                              <td class="text-center">Total</td>
                          </tr>
                          <tr class="content">
                              <td class="text-center">Rs <?php echo e($order->total_amount??''); ?></td>
                          </tr>
                      </tbody>
                  </table>
              </div>
              <hr>
              <div class="address p-2">
                  
              </div>
          </div>
      </div>
  </div>
</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
                            // submitting form
$(document).on('click','#print',function(e){

  e.preventDefault();

  printData();


});

function printData()
{
   var divToPrint=document.getElementById("print_area");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perfumeshop\resources\views/admin/order/print_order.blade.php ENDPATH**/ ?>