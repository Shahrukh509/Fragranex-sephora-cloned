! function() {
    function t(t, e) { return e = { exports: {} }, t(e, e.exports), e.exports } var e = t(function(t) {! function(e, i) { var r = function(t, e) { "use strict"; if (e.getElementsByClassName) { var i, r, a = e.documentElement,
                            n = t.Date,
                            s = t.HTMLPictureElement,
                            o = t.addEventListener,
                            l = t.setTimeout,
                            c = t.requestAnimationFrame || l,
                            u = t.requestIdleCallback,
                            d = /^picture$/i,
                            f = ["load", "error", "lazyincluded", "_lazyloaded"],
                            g = {},
                            z = Array.prototype.forEach,
                            y = function(t, e) { return g[e] || (g[e] = new RegExp("(\\s|^)" + e + "(\\s|$)")), g[e].test(t.getAttribute("class") || "") && g[e] },
                            p = function(t, e) { y(t, e) || t.setAttribute("class", (t.getAttribute("class") || "").trim() + " " + e) },
                            v = function(t, e) { var i;
                                (i = y(t, e)) && t.setAttribute("class", (t.getAttribute("class") || "").replace(i, " ")) },
                            m = function(t, e, i) { var r = i ? "addEventListener" : "removeEventListener";
                                i && m(t, e), f.forEach(function(i) { t[r](i, e) }) },
                            b = function(t, r, a, n, s) { var o = e.createEvent("CustomEvent"); return a || (a = {}), a.instance = i, o.initCustomEvent(r, !n, !s, a), t.dispatchEvent(o), o },
                            A = function(e, i) { var a;!s && (a = t.picturefill || r.pf) ? a({ reevaluate: !0, elements: [e] }) : i && i.src && (e.src = i.src) },
                            h = function(t, e) { return (getComputedStyle(t, null) || {})[e] },
                            C = function(t, e, i) { for (i = i || t.offsetWidth; i < r.minSize && e && !t._lazysizesWidth;) i = e.offsetWidth, e = e.parentNode; return i },
                            E = function() { var t, i, r = [],
                                    a = [],
                                    n = r,
                                    s = function() { var e = n; for (n = r.length ? a : r, t = !0, i = !1; e.length;) e.shift()();
                                        t = !1 },
                                    o = function(r, a) { t && !a ? r.apply(this, arguments) : (n.push(r), i || (i = !0, (e.hidden ? l : c)(s))) }; return o._lsFlush = s, o }(),
                            w = function(t, e) { return e ? function() { E(t) } : function() { var e = this,
                                        i = arguments;
                                    E(function() { t.apply(e, i) }) } },
                            _ = function(t) { var e, i = 0,
                                    a = r.throttleDelay,
                                    s = r.ricTimeout,
                                    o = function() { e = !1, i = n.now(), t() },
                                    c = u && s > 49 ? function() { u(o, { timeout: s }), s !== r.ricTimeout && (s = r.ricTimeout) } : w(function() { l(o) }, !0); return function(t) { var r;
                                    (t = !0 === t) && (s = 33), e || (e = !0, r = a - (n.now() - i), r < 0 && (r = 0), t || r < 9 ? c() : l(c, r)) } },
                            S = function(t) { var e, i, r = function() { e = null, t() },
                                    a = function() { var t = n.now() - i;
                                        t < 99 ? l(a, 99 - t) : (u || r)(r) }; return function() { i = n.now(), e || (e = l(a, 99)) } };! function() { var e, i = { lazyClass: "lazyload", loadedClass: "lazyloaded", loadingClass: "lazyloading", preloadClass: "lazypreload", errorClass: "lazyerror", autosizesClass: "lazyautosizes", srcAttr: "data-src", srcsetAttr: "data-srcset", sizesAttr: "data-sizes", minSize: 40, customMedia: {}, init: !0, expFactor: 1.5, hFac: .8, loadMode: 2, loadHidden: !0, ricTimeout: 0, throttleDelay: 125 };
                            r = t.lazySizesConfig || t.lazysizesConfig || {}; for (e in i) e in r || (r[e] = i[e]);
                            t.lazySizesConfig = r, l(function() { r.init && L() }) }(); var N = function() { var s, c, u, f, g, C, N, L, M, x, F, T, j, W, I = /^img$/i,
                                    O = /^iframe$/i,
                                    k = "onscroll" in t && !/glebot/.test(navigator.userAgent),
                                    B = 0,
                                    R = 0,
                                    $ = -1,
                                    H = function(t) { R--, t && t.target && m(t.target, H), (!t || R < 0 || !t.target) && (R = 0) },
                                    U = function(t, i) { var r, n = t,
                                            s = "hidden" == h(e.body, "visibility") || "hidden" != h(t, "visibility"); for (L -= i, F += i, M -= i, x += i; s && (n = n.offsetParent) && n != e.body && n != a;)(s = (h(n, "opacity") || 1) > 0) && "visible" != h(n, "overflow") && (r = n.getBoundingClientRect(), s = x > r.left && M < r.right && F > r.top - 1 && L < r.bottom + 1); return s },
                                    D = function() { var t, n, o, l, u, d, g, z, y, p = i.elements; if ((f = r.loadMode) && R < 8 && (t = p.length)) { n = 0, $++, null == j && ("expand" in r || (r.expand = a.clientHeight > 500 && a.clientWidth > 500 ? 500 : 370), T = r.expand, j = T * r.expFactor), B < j && R < 1 && $ > 2 && f > 2 && !e.hidden ? (B = j, $ = 0) : B = f > 1 && $ > 1 && R < 6 ? T : 0; for (; n < t; n++)
                                                if (p[n] && !p[n]._lazyRace)
                                                    if (k)
                                                        if ((z = p[n].getAttribute("data-expand")) && (d = 1 * z) || (d = B), y !== d && (C = innerWidth + d * W, N = innerHeight + d, g = -1 * d, y = d), o = p[n].getBoundingClientRect(), (F = o.bottom) >= g && (L = o.top) <= N && (x = o.right) >= g * W && (M = o.left) <= C && (F || x || M || L) && (r.loadHidden || "hidden" != h(p[n], "visibility")) && (c && R < 3 && !z && (f < 3 || $ < 4) || U(p[n], d))) { if (Y(p[n]), u = !0, R > 9) break } else !u && c && !l && R < 4 && $ < 4 && f > 2 && (s[0] || r.preloadAfterLoad) && (s[0] || !z && (F || x || M || L || "auto" != p[n].getAttribute(r.sizesAttr))) && (l = s[0] || p[n]);
                                            else Y(p[n]);
                                            l && !u && Y(l) } },
                                    q = _(D),
                                    X = function(t) { p(t.target, r.loadedClass), v(t.target, r.loadingClass), m(t.target, Q), b(t.target, "lazyloaded") },
                                    J = w(X),
                                    Q = function(t) { J({ target: t.target }) },
                                    V = function(t, e) { try { t.contentWindow.location.replace(e) } catch (i) { t.src = e } },
                                    G = function(t) { var e, i = t.getAttribute(r.srcsetAttr);
                                        (e = r.customMedia[t.getAttribute("data-media") || t.getAttribute("media")]) && t.setAttribute("media", e), i && t.setAttribute("srcset", i) },
                                    K = w(function(t, e, i, a, n) { var s, o, c, f, g, y;
                                        (g = b(t, "lazybeforeunveil", e)).defaultPrevented || (a && (i ? p(t, r.autosizesClass) : t.setAttribute("sizes", a)), o = t.getAttribute(r.srcsetAttr), s = t.getAttribute(r.srcAttr), n && (c = t.parentNode, f = c && d.test(c.nodeName || "")), y = e.firesLoad || "src" in t && (o || s || f), g = { target: t }, y && (m(t, H, !0), clearTimeout(u), u = l(H, 2500), p(t, r.loadingClass), m(t, Q, !0)), f && z.call(c.getElementsByTagName("source"), G), o ? t.setAttribute("srcset", o) : s && !f && (O.test(t.nodeName) ? V(t, s) : t.src = s), n && (o || f) && A(t, { src: s })), t._lazyRace && delete t._lazyRace, v(t, r.lazyClass), E(function() {
                                            (!y || t.complete && t.naturalWidth > 1) && (y ? H(g) : R--, X(g)) }, !0) }),
                                    Y = function(t) { var e, i = I.test(t.nodeName),
                                            a = i && (t.getAttribute(r.sizesAttr) || t.getAttribute("sizes")),
                                            n = "auto" == a;
                                        (!n && c || !i || !t.getAttribute("src") && !t.srcset || t.complete || y(t, r.errorClass) || !y(t, r.lazyClass)) && (e = b(t, "lazyunveilread").detail, n && P.updateElem(t, !0, t.offsetWidth), t._lazyRace = !0, R++, K(t, e, n, a, i)) },
                                    Z = function() { if (!c) { if (n.now() - g < 999) return void l(Z, 999); var t = S(function() { r.loadMode = 3, q() });
                                            c = !0, r.loadMode = 3, q(), o("scroll", function() { 3 == r.loadMode && (r.loadMode = 2), t() }, !0) } }; return { _: function() { g = n.now(), i.elements = e.getElementsByClassName(r.lazyClass), s = e.getElementsByClassName(r.lazyClass + " " + r.preloadClass), W = r.hFac, o("scroll", q, !0), o("resize", q, !0), t.MutationObserver ? new MutationObserver(q).observe(a, { childList: !0, subtree: !0, attributes: !0 }) : (a.addEventListener("DOMNodeInserted", q, !0), a.addEventListener("DOMAttrModified", q, !0), setInterval(q, 999)), o("hashchange", q, !0), ["focus", "mouseover", "click", "load", "transitionend", "animationend", "webkitAnimationEnd"].forEach(function(t) { e.addEventListener(t, q, !0) }), /d$|^c/.test(e.readyState) ? Z() : (o("load", Z), e.addEventListener("DOMContentLoaded", q), l(Z, 2e4)), i.elements.length ? (D(), E._lsFlush()) : q() }, checkElems: q, unveil: Y } }(),
                            P = function() { var t, i = w(function(t, e, i, r) { var a, n, s; if (t._lazysizesWidth = r, r += "px", t.setAttribute("sizes", r), d.test(e.nodeName || ""))
                                            for (a = e.getElementsByTagName("source"), n = 0, s = a.length; n < s; n++) a[n].setAttribute("sizes", r);
                                        i.detail.dataAttr || A(t, i.detail) }),
                                    a = function(t, e, r) { var a, n = t.parentNode;
                                        n && (r = C(t, n, r), a = b(t, "lazybeforesizes", { width: r, dataAttr: !!e }), a.defaultPrevented || (r = a.detail.width) && r !== t._lazysizesWidth && i(t, n, a, r)) },
                                    n = function() { var e, i = t.length; if (i)
                                            for (e = 0; e < i; e++) a(t[e]) },
                                    s = S(n); return { _: function() { t = e.getElementsByClassName(r.autosizesClass), o("resize", s) }, checkElems: s, updateElem: a } }(),
                            L = function() { L.i || (L.i = !0, P._(), N._()) }; return i = { cfg: r, autoSizer: P, loader: N, init: L, uP: A, aC: p, rC: v, hC: y, fire: b, gW: C, rAF: E } } }(e, e.document);
                e.lazySizes = r, "object" == typeof t && t.exports && (t.exports = r) }(window) }),
        i = (t(function(t) {! function(i, r) { var a = function(t) { r(i.lazySizes, t), i.removeEventListener("lazyunveilread", a, !0) };
                r = r.bind(null, i, i.document), "object" == typeof t && t.exports ? r(e) : i.lazySizes ? a() : i.addEventListener("lazyunveilread", a, !0) }(window, function(t, e, i, r) { "use strict";

                function a(t) { var e = getComputedStyle(t, null) || {},
                        i = e.fontFamily || "",
                        r = i.match(c) || "",
                        a = r && i.match(u) || ""; return a && (a = a[1]), { fit: r && r[1] || "", position: g[a] || a || "center" } }

                function n(t, e) { var r, a, n = i.cfg,
                        s = t.cloneNode(!1),
                        o = s.style,
                        l = function() { var e = t.currentSrc || t.src;
                            e && a !== e && (a = e, o.backgroundImage = "url(" + (f.test(e) ? JSON.stringify(e) : e) + ")", r || (r = !0, i.rC(s, n.loadingClass), i.aC(s, n.loadedClass))) },
                        c = function() { i.rAF(l) };
                    t._lazysizesParentFit = e.fit, t.addEventListener("lazyloaded", c, !0), t.addEventListener("load", c, !0), s.addEventListener("load", function() { var t = s.currentSrc || s.src;
                        t && t != d && (s.src = d, s.srcset = "") }), i.rAF(function() { var r = t,
                            a = t.parentNode; "PICTURE" == a.nodeName.toUpperCase() && (r = a, a = a.parentNode), i.rC(s, n.loadedClass), i.rC(s, n.lazyClass), i.aC(s, n.loadingClass), i.aC(s, n.objectFitClass || "lazysizes-display-clone"), s.getAttribute(n.srcsetAttr) && s.setAttribute(n.srcsetAttr, ""), s.getAttribute(n.srcAttr) && s.setAttribute(n.srcAttr, ""), s.src = d, s.srcset = "", o.backgroundRepeat = "no-repeat", o.backgroundPosition = e.position, o.backgroundSize = e.fit, r.style.display = "none", t.setAttribute("data-parent-fit", e.fit), t.setAttribute("data-parent-container", "prev"), a.insertBefore(s, r), t._lazysizesParentFit && delete t._lazysizesParentFit, t.complete && l() }) } var s = e.createElement("a").style,
                    o = "objectFit" in s,
                    l = o && "objectPosition" in s,
                    c = /object-fit["']*\s*:\s*["']*(contain|cover)/,
                    u = /object-position["']*\s*:\s*["']*(.+?)(?=($|,|'|"|;))/,
                    d = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",
                    f = /\(|\)|'/,
                    g = { center: "center", "50% 50%": "center" }; if (!o || !l) { var z = function(t) { if (t.detail.instance == i) { var e = t.target,
                                r = a(e);!r.fit || o && "center" == r.position || n(e, r) } };
                    t.addEventListener("lazyunveilread", z, !0), r && r.detail && z(r) } }) }), t(function(t) {! function(i, r) { var a = function() { r(i.lazySizes), i.removeEventListener("lazyunveilread", a, !0) };
                r = r.bind(null, i, i.document), "object" == typeof t && t.exports ? r(e) : i.lazySizes ? a() : i.addEventListener("lazyunveilread", a, !0) }(window, function(t, e, i) { "use strict"; if (t.addEventListener) { var r = /\s+(\d+)(w|h)\s+(\d+)(w|h)/,
                        a = /parent-fit["']*\s*:\s*["']*(contain|cover|width)/,
                        n = /parent-container["']*\s*:\s*["']*(.+?)(?=(\s|$|,|'|"|;))/,
                        s = /^picture$/i,
                        o = function(t) { return getComputedStyle(t, null) || {} },
                        l = { getParent: function(e, i) { var r = e,
                                    a = e.parentNode; return i && "prev" != i || !a || !s.test(a.nodeName || "") || (a = a.parentNode), "self" != i && (r = "prev" == i ? e.previousElementSibling : i && (a.closest || t.jQuery) ? (a.closest ? a.closest(i) : jQuery(a).closest(i)[0]) || a : a), r }, getFit: function(t) { var e, i, r = o(t),
                                    s = r.content || r.fontFamily,
                                    c = { fit: t._lazysizesParentFit || t.getAttribute("data-parent-fit") }; return !c.fit && s && (e = s.match(a)) && (c.fit = e[1]), c.fit ? (i = t._lazysizesParentContainer || t.getAttribute("data-parent-container"), !i && s && (e = s.match(n)) && (i = e[1]), c.parent = l.getParent(t, i)) : c.fit = r.objectFit, c }, getImageRatio: function(e) { var i, a, n, o, l, c = e.parentNode,
                                    u = c && s.test(c.nodeName || "") ? c.querySelectorAll("source, img") : [e]; for (i = 0; i < u.length; i++)
                                    if (e = u[i], a = e.getAttribute(lazySizesConfig.srcsetAttr) || e.getAttribute("srcset") || e.getAttribute("data-pfsrcset") || e.getAttribute("data-risrcset") || "", n = e._lsMedia || e.getAttribute("media"), n = lazySizesConfig.customMedia[e.getAttribute("data-media") || n] || n, a && (!n || (t.matchMedia && matchMedia(n) || {}).matches)) { o = parseFloat(e.getAttribute("data-aspectratio")), !o && (l = a.match(r)) && (o = "w" == l[2] ? l[1] / l[3] : l[3] / l[1]); break }
                                return o }, calculateSize: function(t, e) { var i, r, a, n, s = this.getFit(t),
                                    o = s.fit,
                                    l = s.parent; return "width" == o || ("contain" == o || "cover" == o) && (a = this.getImageRatio(t)) ? (l ? e = l.clientWidth : l = t, n = e, "width" == o ? n = e : (r = l.clientHeight) > 40 && (i = e / r) && ("cover" == o && i < a || "contain" == o && i > a) && (n = e * (a / i)), n) : e } };
                    i.parentFit = l, e.addEventListener("lazybeforesizes", function(t) { if (!t.defaultPrevented && t.detail.instance == i) { var e = t.target;
                            t.detail.width = l.calculateSize(e, t.detail.width) } }) } }) }), t(function(t) {! function(i, r) { var a = function() { r(i.lazySizes), i.removeEventListener("lazyunveilread", a, !0) };
                r = r.bind(null, i, i.document), "object" == typeof t && t.exports ? r(e) : i.lazySizes ? a() : i.addEventListener("lazyunveilread", a, !0) }(window, function(t, e, i) { "use strict";

                function r(e, i) { var r, a, n, s, o = t.getComputedStyle(e);
                    a = e.parentNode, s = { isPicture: !(!a || !f.test(a.nodeName || "")) }, n = function(t, i) { var r = e.getAttribute("data-" + t); if (!r) { var a = o.getPropertyValue("--ls-" + t);
                            a && (r = a.trim()) } if (r) { if ("true" == r) r = !0;
                            else if ("false" == r) r = !1;
                            else if (d.test(r)) r = parseFloat(r);
                            else if ("function" == typeof c[t]) r = c[t](e, r);
                            else if (p.test(r)) try { r = JSON.parse(r) } catch (t) {}
                            s[t] = r } else t in c && "function" != typeof c[t] ? s[t] = c[t] : i && "function" == typeof c[t] && (s[t] = c[t](e, r)) }; for (r in c) n(r); return i.replace(y, function(t, e) { e in s || n(e, !0) }), s }

                function a(t, e) { var i = [],
                        r = function(t, i) { return u[typeof e[i]] ? e[i] : t }; return i.srcset = [], e.absUrl && (m.setAttribute("href", t), t = m.href), t = ((e.prefix || "") + t + (e.postfix || "")).replace(y, r), e.widths.forEach(function(r) { var a = e.widthmap[r] || r,
                            n = { u: t.replace(g, a).replace(z, e.ratio ? Math.round(r * e.ratio) : ""), w: r };
                        i.push(n), i.srcset.push(n.c = n.u + " " + r + "w") }), i }

                function n(t, i, r) { var n = 0,
                        s = 0,
                        o = r; if (t) { if ("container" === i.ratio) { for (n = o.scrollWidth, s = o.scrollHeight; !(n && s || o === e);) o = o.parentNode, n = o.scrollWidth, s = o.scrollHeight;
                            n && s && (i.ratio = s / n) }
                        t = a(t, i), t.isPicture = i.isPicture, A && "IMG" == r.nodeName.toUpperCase() ? r.removeAttribute(l.srcsetAttr) : r.setAttribute(l.srcsetAttr, t.srcset.join(", ")), Object.defineProperty(r, "_lazyrias", { value: t, writable: !0 }) } }

                function s(t, e) { var a = r(t, e); return c.modifyOptions.call(t, { target: t, details: a, detail: a }), i.fire(t, "lazyriasmodifyoptions", a), a }

                function o(t) { return t.getAttribute(t.getAttribute("data-srcattr") || c.srcAttr) || t.getAttribute(l.srcsetAttr) || t.getAttribute(l.srcAttr) || t.getAttribute("data-pfsrcset") || "" } var l, c, u = { string: 1, number: 1 },
                    d = /^\-*\+*\d+\.*\d*$/,
                    f = /^picture$/i,
                    g = /\s*\{\s*width\s*\}\s*/i,
                    z = /\s*\{\s*height\s*\}\s*/i,
                    y = /\s*\{\s*([a-z0-9]+)\s*\}\s*/gi,
                    p = /^\[.*\]|\{.*\}$/,
                    v = /^(?:auto|\d+(px)?)$/,
                    m = e.createElement("a"),
                    b = e.createElement("img"),
                    A = "srcset" in b && !("sizes" in b),
                    h = !!t.HTMLPictureElement && !A;! function() { var e, r = function() {},
                        a = { prefix: "", postfix: "", srcAttr: "data-src", absUrl: !1, modifyOptions: r, widthmap: {}, ratio: !1 };
                    l = i && i.cfg || t.lazySizesConfig, l || (l = {}, t.lazySizesConfig = l), l.supportsType || (l.supportsType = function(t) { return !t }), l.rias || (l.rias = {}), "widths" in (c = l.rias) || (c.widths = [], function(t) { for (var e, i = 0; !e || e < 3e3;) i += 5, i > 30 && (i += 1), e = 36 * i, t.push(e) }(c.widths)); for (e in a) e in c || (c[e] = a[e]) }(), addEventListener("lazybeforesizes", function(t) { if (t.detail.instance == i) { var e, r, a, u, d, f, z, y, p, m, b, A, E; if (e = t.target, t.detail.dataAttr && !t.defaultPrevented && !c.disabled && (p = e.getAttribute(l.sizesAttr) || e.getAttribute("sizes")) && v.test(p)) { if (r = o(e), a = s(e, r), b = g.test(a.prefix) || g.test(a.postfix), a.isPicture && (u = e.parentNode))
                                for (d = u.getElementsByTagName("source"), f = 0, z = d.length; f < z; f++)(b || g.test(y = o(d[f]))) && (n(y, a, d[f]), A = !0);
                            b || g.test(r) ? (n(r, a, e), A = !0) : A && (E = [], E.srcset = [], E.isPicture = !0, Object.defineProperty(e, "_lazyrias", { value: E, writable: !0 })), A && (h ? e.removeAttribute(l.srcAttr) : "auto" != p && (m = { width: parseInt(p, 10) }, C({ target: e, detail: m }))) } } }, !0); var C = function() { var r = function(t, e) { return t.w - e.w },
                        a = function(t) { var e, i, r = t.length,
                                a = t[r - 1],
                                n = 0; for (n; n < r; n++)
                                if (a = t[n], a.d = a.w / t.w, a.d >= t.d) {!a.cached && (e = t[n - 1]) && e.d > t.d - .13 * Math.pow(t.d, 2.2) && (i = Math.pow(e.d - .6, 1.6), e.cached && (e.d += .15 * i), e.d + (a.d - t.d) * i > t.d && (a = e)); break }
                            return a },
                        n = function(t, e) { var r; return !t._lazyrias && i.pWS && (r = i.pWS(t.getAttribute(l.srcsetAttr || ""))).length && (Object.defineProperty(t, "_lazyrias", { value: r, writable: !0 }), e && t.parentNode && (r.isPicture = "PICTURE" == t.parentNode.nodeName.toUpperCase())), t._lazyrias },
                        s = function(e) { var r = t.devicePixelRatio || 1,
                                a = i.getX && i.getX(e); return Math.min(a || r, 2.4, r) },
                        o = function(e, i) { var o, l, c, u, d, f; if (d = e._lazyrias, d.isPicture && t.matchMedia)
                                for (l = 0, o = e.parentNode.getElementsByTagName("source"), c = o.length; l < c; l++)
                                    if (n(o[l]) && !o[l].getAttribute("type") && (!(u = o[l].getAttribute("media")) || (matchMedia(u) || {}).matches)) { d = o[l]._lazyrias; break }
                            return (!d.w || d.w < i) && (d.w = i, d.d = s(e), f = a(d.sort(r))), f },
                        c = function(r) { if (r.detail.instance == i) { var a, s = r.target; if (!A && (t.respimage || t.picturefill || lazySizesConfig.pf)) return void e.removeEventListener("lazybeforesizes", c);
                                ("_lazyrias" in s || r.detail.dataAttr && n(s, !0)) && (a = o(s, r.detail.width)) && a.u && s._lazyrias.cur != a.u && (s._lazyrias.cur = a.u, a.cached = !0, i.rAF(function() { s.setAttribute(l.srcAttr, a.u), s.setAttribute("src", a.u) })) } }; return h ? c = function() {} : addEventListener("lazybeforesizes", c), c }() }) }), t(function(t) {! function(i, r) { var a = function() { r(i.lazySizes), i.removeEventListener("lazyunveilread", a, !0) };
                r = r.bind(null, i, i.document), "object" == typeof t && t.exports ? r(e) : i.lazySizes ? a() : i.addEventListener("lazyunveilread", a, !0) }(window, function(t, e, i) { "use strict"; if (t.addEventListener) { var r = /\s+/g,
                        a = /\s*\|\s+|\s+\|\s*/g,
                        n = /^(.+?)(?:\s+\[\s*(.+?)\s*\])?$/,
                        s = /\(|\)|'/,
                        o = { contain: 1, cover: 1 },
                        l = function(t) { var e = i.gW(t, t.parentNode); return (!t._lazysizesWidth || e > t._lazysizesWidth) && (t._lazysizesWidth = e), t._lazysizesWidth },
                        c = function(t) { var e; return e = (getComputedStyle(t) || { getPropertyValue: function() {} }).getPropertyValue("background-size"), !o[e] && o[t.style.backgroundSize] && (e = t.style.backgroundSize), e },
                        u = function(t, i, s) { var o = e.createElement("picture"),
                                l = i.getAttribute(lazySizesConfig.sizesAttr),
                                c = i.getAttribute("data-ratio"),
                                u = i.getAttribute("data-optimumx");
                            i._lazybgset && i._lazybgset.parentNode == i && i.removeChild(i._lazybgset), Object.defineProperty(s, "_lazybgset", { value: i, writable: !0 }), Object.defineProperty(i, "_lazybgset", { value: o, writable: !0 }), t = t.replace(r, " ").split(a), o.style.display = "none", s.className = lazySizesConfig.lazyClass, 1 != t.length || l || (l = "auto"), t.forEach(function(t) { var i, r = e.createElement("source");
                                l && "auto" != l && r.setAttribute("sizes", l), (i = t.match(n)) && (r.setAttribute(lazySizesConfig.srcsetAttr, i[1]), i[2] && r.setAttribute("media", lazySizesConfig.customMedia[i[2]] || i[2])), o.appendChild(r) }), l && (s.setAttribute(lazySizesConfig.sizesAttr, l), i.removeAttribute(lazySizesConfig.sizesAttr), i.removeAttribute("sizes")), u && s.setAttribute("data-optimumx", u), c && s.setAttribute("data-ratio", c), o.appendChild(s), i.appendChild(o) },
                        d = function(t) { if (t.target._lazybgset) { var e = t.target,
                                    r = e._lazybgset,
                                    a = e.currentSrc || e.src;
                                a && (r.style.backgroundImage = "url(" + (s.test(a) ? JSON.stringify(a) : a) + ")"), e._lazybgsetLoading && (i.fire(r, "_lazyloaded", {}, !1, !0), delete e._lazybgsetLoading) } };
                    addEventListener("lazybeforeunveil", function(t) { var r, a, n;!t.defaultPrevented && (r = t.target.getAttribute("data-bgset")) && (n = t.target, a = e.createElement("img"), a.alt = "", a._lazybgsetLoading = !0, t.detail.firesLoad = !0, u(r, n, a), setTimeout(function() { i.loader.unveil(a), i.rAF(function() { i.fire(a, "_lazyloaded", {}, !0, !0), a.complete && d({ target: a }) }) })) }), e.addEventListener("load", d, !0), t.addEventListener("lazybeforesizes", function(t) { if (t.detail.instance == i && t.target._lazybgset && t.detail.dataAttr) { var e = t.target._lazybgset,
                                r = c(e);
                            o[r] && (t.target._lazysizesParentFit = r, i.rAF(function() { t.target.setAttribute("data-parent-fit", r), t.target._lazysizesParentFit && delete t.target._lazysizesParentFit })) } }, !0), e.documentElement.addEventListener("lazybeforesizes", function(t) {!t.defaultPrevented && t.target._lazybgset && t.detail.instance == i && (t.detail.width = l(t.target._lazybgset)) }) } }) }), t(function(t) {! function(i, r) { var a = function() { r(i.lazySizes), i.removeEventListener("lazyunveilread", a, !0) };
                r = r.bind(null, i, i.document), "object" == typeof t && t.exports ? r(e) : i.lazySizes ? a() : i.addEventListener("lazyunveilread", a, !0) }(window, function(t, e, i) { "use strict"; var r, a = e.createElement("img");!("srcset" in a) || "sizes" in a || t.HTMLPictureElement || (r = /^picture$/i, e.addEventListener("lazybeforeunveil", function(t) { if (t.detail.instance == i) { var a, n, s, o, l, c, u;!t.defaultPrevented && !lazySizesConfig.noIOSFix && (a = t.target) && (s = a.getAttribute(lazySizesConfig.srcsetAttr)) && (n = a.parentNode) && ((l = r.test(n.nodeName || "")) || (o = a.getAttribute("sizes") || a.getAttribute(lazySizesConfig.sizesAttr))) && (c = l ? n : e.createElement("picture"), a._lazyImgSrc || Object.defineProperty(a, "_lazyImgSrc", { value: e.createElement("source"), writable: !0 }), u = a._lazyImgSrc, o && u.setAttribute("sizes", o), u.setAttribute(lazySizesConfig.srcsetAttr, s), a.setAttribute("data-pfsrcset", s), a.removeAttribute(lazySizesConfig.srcsetAttr), l || (n.insertBefore(c, a), c.appendChild(a)), c.insertBefore(u, a)) } })) }) }));
    t(function(t) {! function(r, a) { var n = function() { a(r.lazySizes), r.removeEventListener("lazyunveilread", n, !0) };
            a = a.bind(null, r, r.document), "object" == typeof t && t.exports ? a(e, i) : r.lazySizes ? n() : r.addEventListener("lazyunveilread", n, !0) }(window, function(t, e, i) { "use strict"; var r, a = i && i.cfg || t.lazySizesConfig,
                n = e.createElement("img"),
                s = "sizes" in n && "srcset" in n,
                o = /\s+\d+h/g,
                l = function() { var t = /\s+(\d+)(w|h)\s+(\d+)(w|h)/,
                        i = Array.prototype.forEach; return function(r) { var a = e.createElement("img"),
                            n = function(e) { var i, r, a = e.getAttribute(lazySizesConfig.srcsetAttr);
                                a && ((r = a.match(t)) && (i = "w" == r[2] ? r[1] / r[3] : r[3] / r[1]) && e.setAttribute("data-aspectratio", i), e.setAttribute(lazySizesConfig.srcsetAttr, a.replace(o, ""))) },
                            s = function(t) { var e = t.target.parentNode;
                                e && "PICTURE" == e.nodeName && i.call(e.getElementsByTagName("source"), n), n(t.target) },
                            l = function() { a.currentSrc && e.removeEventListener("lazybeforeunveil", s) };
                        r[1] && (e.addEventListener("lazybeforeunveil", s), a.onload = l, a.onerror = l, a.srcset = "data:,a 1w 1h", a.complete && l()) } }(); if (a || (a = {}, t.lazySizesConfig = a), a.supportsType || (a.supportsType = function(t) { return !t }), !t.picturefill && !a.pf) { if (t.HTMLPictureElement && s) return e.msElementsFromPoint && l(navigator.userAgent.match(/Edge\/(\d+)/)), void(a.pf = function() {});
                a.pf = function(e) { var i, a; if (!t.picturefill)
                        for (i = 0, a = e.elements.length; i < a; i++) r(e.elements[i]) }, r = function() { var n = function(t, e) { return t.w - e.w },
                        l = /^\s*\d+\.*\d*px\s*$/,
                        c = function(t) { var e, i, r = t.length,
                                a = t[r - 1],
                                n = 0; for (n; n < r; n++)
                                if (a = t[n], a.d = a.w / t.w, a.d >= t.d) {!a.cached && (e = t[n - 1]) && e.d > t.d - .13 * Math.pow(t.d, 2.2) && (i = Math.pow(e.d - .6, 1.6), e.cached && (e.d += .15 * i), e.d + (a.d - t.d) * i > t.d && (a = e)); break }
                            return a },
                        u = function() { var t, e = /(([^,\s].[^\s]+)\s+(\d+)w)/g,
                                i = /\s/,
                                r = function(e, i, r, a) { t.push({ c: i, u: r, w: 1 * a }) }; return function(a) { return t = [], a = a.trim(), a.replace(o, "").replace(e, r), t.length || !a || i.test(a) || t.push({ c: a, u: a, w: 99 }), t } }(),
                        d = function() { d.init || (d.init = !0, addEventListener("resize", function() { var t, i = e.getElementsByClassName("lazymatchmedia"),
                                    a = function() { var t, e; for (t = 0, e = i.length; t < e; t++) r(i[t]) }; return function() { clearTimeout(t), t = setTimeout(a, 66) } }())) },
                        f = function(e, r) { var n, s = e.getAttribute("srcset") || e.getAttribute(a.srcsetAttr);!s && r && (s = e._lazypolyfill ? e._lazypolyfill._set : e.getAttribute(a.srcAttr) || e.getAttribute("src")), e._lazypolyfill && e._lazypolyfill._set == s || (n = u(s || ""), r && e.parentNode && (n.isPicture = "PICTURE" == e.parentNode.nodeName.toUpperCase(), n.isPicture && t.matchMedia && (i.aC(e, "lazymatchmedia"), d())), n._set = s, Object.defineProperty(e, "_lazypolyfill", { value: n, writable: !0 })) },
                        g = function(e) { var r = t.devicePixelRatio || 1,
                                a = i.getX && i.getX(e); return Math.min(a || r, 2.5, r) },
                        z = function(e) { return t.matchMedia ? (z = function(t) { return !t || (matchMedia(t) || {}).matches })(e) : !e },
                        y = function(t) { var e, r, s, o, u, d, y; if (o = t, f(o, !0), u = o._lazypolyfill, u.isPicture)
                                for (r = 0, e = t.parentNode.getElementsByTagName("source"), s = e.length; r < s; r++)
                                    if (a.supportsType(e[r].getAttribute("type"), t) && z(e[r].getAttribute("media"))) { o = e[r], f(o), u = o._lazypolyfill; break }
                            return u.length > 1 ? (y = o.getAttribute("sizes") || "", y = l.test(y) && parseInt(y, 10) || i.gW(t, t.parentNode), u.d = g(t), !u.src || !u.w || u.w < y ? (u.w = y, d = c(u.sort(n)), u.src = d) : d = u.src) : d = u[0], d },
                        p = function(t) { if (!s || !t.parentNode || "PICTURE" == t.parentNode.nodeName.toUpperCase()) { var e = y(t);
                                e && e.u && t._lazypolyfill.cur != e.u && (t._lazypolyfill.cur = e.u, e.cached = !0, t.setAttribute(a.srcAttr, e.u), t.setAttribute("src", e.u)) } }; return p.parse = u, p }(), a.loadedClass && a.loadingClass && function() { var t = [];
                    ['img[sizes$="px"][srcset].', "picture > img:not([srcset])."].forEach(function(e) { t.push(e + a.loadedClass), t.push(e + a.loadingClass) }), a.pf({ elements: e.querySelectorAll(t.join(", ")) }) }() } }) }) }();