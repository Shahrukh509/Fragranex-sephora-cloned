
{{-- {{ dd($product->image->path) }} --}}
<div class="product-single">
    <div class="row">
        <div class="col-lg-5 col-md-6 col-sm-12 col-12">
            <div class="product-details-img">
                <div class="product-thumb">
                    <div id="gallery" class="product-dec-slider-2 product-tab-left slick-initialized slick-slider slick-vertical">
                        <button class="slick-prev slick-arrow" aria-label="Previous" type="button" style="">Previous</button>
                        <div class="slick-list draggable" style="height: 280px;"><div class="slick-track" style="opacity: 1; height: 1512px; transform: translate3d(0px, -459px, 0px);">
                            <div class="slick-slide slick-cloned" data-slick-index="-5" id="" aria-hidden="true" style="width: 51px;" tabindex="-1">
                                <div>
                                    <a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="2" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a>
                       </div>
                    </div>
                    
                <div class="slick-slide slick-cloned" data-slick-index="-3" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="4" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        
                        <div class="slick-slide slick-cloned" data-slick-index="-2" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="5" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a></div></div>
                        <div class="slick-slide slick-cloned" data-slick-index="-1" id="" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="6" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="0" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="-4" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="1" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="-3" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a></div></div><div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" data-zoom-image="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" class="slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/sku/s2249696-main-zoom.jpg?imwidth=465" alt="">
                        </a></div></div>
                        <div class="slick-slide" data-slick-index="3" aria-hidden="true" style="width: 51px;" tabindex="-1"><div><a data-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" data-zoom-image="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" class="slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="https://www.sephora.com/productimages/product/p449116-av-19-zoom.jpg?imwidth=930" alt="">
                        </a>
                    </div>
                </div>
                @php
                $parent = \App\Models\Product::where('id',$product->product_id)->first();
        
                @endphp
                @foreach($parent->all_variable_products as $get_image)
                   <div class="slick-slide slick-current slick-active" data-slick-index="4" aria-hidden="false" style="width: 51px;"><div><a data-image="{{ $get_image->image->path??'' }}" data-zoom-image="{{ $get_image->image->path??'' }}" class="slick-slide slick-cloned" data-slick-index="0" aria-hidden="true" tabindex="0" style="width: 100%; display: inline-block;">
                            <img class="blur-up ls-is-cached lazyloaded" src="{{ $get_image->image->path??'' }}" alt="">
                        </a>
                    </div>
                    
                    </div>
               @endforeach
            </div>
        </div>
        <button class="slick-next slick-arrow" aria-label="Next" type="button" style="">Next</button></div>
                </div>
                <div class="zoompro-wrap product-zoom-right pl-20">
                    <div class="zoompro-span">
                        <img class="blur-up zoompro lazyloaded" data-zoom-image="{{ $product->image->path??"" }}" alt="" src="{{ $product->image->path??"" }}">
                    </div>
                    <!-- <div class="product-labels"><span class="lbl on-sale">Sale</span><span class="lbl pr-label1">new</span></div>
                    <div class="product-buttons">
                        <a href="https://www.youtube.com/watch?v=93A2jOW5Mog" class="btn popup-video" title="View Video"><i class="icon anm anm-play-r" aria-hidden="true"></i></a>
                        <a href="#" class="btn prlightbox" title="Zoom"><i class="icon anm anm-expand-l-arrows"
                                aria-hidden="true"></i></a>
                    </div> -->
                </div>
                <!-- <div class="lightboximages">
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>
                    <a href="img/camelia-reversible0.jpg" data-size="1462x2048"></a>

                </div> -->

            </div>
        </div>
        <div class="col-lg-7 col-md-6 col-sm-12 col-12">
            <div class="product-single__meta">
                <h1 class="product-single__title">{{ $product->product->brand->name??'' }}</h1>
                <h6>{{ $product->product->name??'' }} {{ $product->product->type->name??'' }}</h6>
                <div class="product-nav clearfix">
                    <a href="#" class="next" title="Next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                </div>
                <div class="prInfoRow">
                    <div class="product-stock">@if($product->product->variable_products->in_stock)<span class="instock ">In Stock</span>@else<span class="outstock hide">Unavailable</span>@endif</div>
                    <div class="product-sku">Item: <span class="variant-sku">#{{ $product->product->variable_products->id??'' }}</span></div>
                    <div class="product-review"><a class="reviewLink" href="#tab2"><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star"></i><i class="font-13 fa fa-star-o"></i><i class="font-13 fa fa-star-o"></i><span class="spr-badge-caption">6
                                reviews</span></a></div>
                </div>
                <p class="product-single__price product-single__price-product-template">
                    <!-- <span class="visually-hidden">Regular price</span>
                    <s id="ComparePrice-product-template"><span class="money">$600.00</span></s> -->
                    <span class="product-price__price product-price__price-product-template product-price__sale product-price__sale--single">
                        <span id="ProductPrice-product-template"><span class="money">Rs {{ number_format($product->price)??'' }}</span></span>
                    </span>
                    {{-- <span class="discount-badge"> <span class="devider">|</span>&nbsp;
                    <span>get it for $109.25 (5% Off) with Auto-Replenish</span>
                    <span id="SaveAmount-product-template" class="product-single__save-amount">
                            <span class="money">$100.00</span>
                    </span>
                    <span class="off">(<span>16</span>%)</span>
                    </span> --}}
                </p>
                {{-- <div class="orderMsg" data-user="23" data-time="24">
                    <img src="assets/images/order-icon.jpg" alt=""> or 4 payments of $28.75 with

                </div> --}}
                <p>Size: {{ $product->size??'' }} {{ $product->type->name??'' }}</p>
            </div>



            <div class="standard_size pb-4">
                <div class="container">
                    <h6>Sizes</h6>
                    <div class="row">

                        @foreach($product->product->all_variable_products as $key=>$pro)

                        

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                            <div style="cursor: pointer;" class="perfume_box p-0 select-size {{ ($pro->id==$product->id)?'border-danger':'' }}" id="{{ $pro->id??'' }}">
                                <div class="row">
                                    
                                    <div class="col-4">

                                        <img src="img/s2249688+sw-42.webp" alt="" class="img-fluid ">
                                    </div>
                                     
                                    <div class="col-8 d-flex">
                                        <span class=" ml_size">{{ $pro->size??'' }} {{ $pro->type->name??'' }}
                                        
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        @endforeach

                        {{-- <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                            <div class="perfume_box p-0">
                                <div class="row">
                                    <div class="col-4">

                                        <img src="img/s2249688+sw-42.webp" alt="" class="img-fluid ">
                                    </div>

                                    <div class="col-8 d-flex">
                                        <span class=" ml_size">1.7 oz/ 50 mL Eau de Parfum Spray
                        
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div> --}}

                        


                    </div>

                    <br>
                    {{-- <h6>Mini size</h6> --}}
                    {{-- <div class="row  ">

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
                            <div class="perfume_box p-0">
                                <div class="row">
                                    <div class="col-4">

                                        <img src="img/s2249688+sw-42.webp" alt="" class="img-fluid ">
                                    </div>

                                    <div class="col-8 d-flex">
                                        <span class=" ml_size">1.7 oz/ 50 mL Eau de Parfum Spray
                    
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div>




                    </div> --}}
                </div>


            </div>

            <!-- Product Action -->
            <div class="product-action clearfix  product-template__container">
                <div class="product-form__item--quantity ">
                    <div class="wrapQtyBtn">
                        <div class="qtyField">
                            <a class="qtyBtn minus" href="javascript:void(0);">
                                <i class="" aria-hidden="true"></i>-</a>
                            <input type="text" id="Quantity" name="quantity" value="1" class="product-form__input qty">
                            <a class="qtyBtn plus" href="javascript:void(0);">
                                <i class="" aria-hidden="true">+</i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="product-form__item--submit">
                    <button type="button" name="add" class="btn product-form__cart-submit add-to-cart" id={{ $product->id??''}}>
                            <span>Add to cart</span>
                        </button>
                </div>
                {{-- <div class="shopify-payment-button" data-shopify="payment-button">
                    <button type="button" class="shopify-payment-button__button shopify-payment-button__button--unbranded">Buy it
                            now</button>
                </div> --}}
            </div>
            <!-- End Product Action -->

            <p id="freeShipMsg" class="freeShipMsg" data-price="199"><i class="fa fa-truck" aria-hidden="true"></i> GETTING CLOSER! ONLY <b class="freeShip"><span class="money" data-currency-usd="$199.00" data-currency="USD">$199.00</span></b> AWAY FROM <b>FREE SHIPPING!</b></p>
            <p class="shippingMsg"><i class="fa fa-clock-o" aria-hidden="true"></i> ESTIMATED DELIVERY BETWEEN <b id="fromDate">Wed. May 1</b> and <b id="toDate">Tue. May 7</b>.</p>
            <!-- <div class="userViewMsg" data-user="20" data-time="11000"><i class="fa fa-users" aria-hidden="true"></i>
                <strong class="uersView">14</strong> PEOPLE ARE LOOKING FOR THIS PRODUCT</div> -->
        </div>
    </div>
</div>